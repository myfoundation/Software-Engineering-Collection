## Contributing

If you find any grammatical issue, please report it using Github Issues. Or, if some sentence or paragraph is difficult to understand, feel free to make a pull request. This manual is in active development and I'll regularly update and improve it. I am not a native English speaker so feel free to correct me if something is not properly written.<br><br>If you have any question related to the material or the development of the language, feel free to open a GitHub issue or to contact me.

### About me
I am Marco Bambini and you can reach me at:
* Twitter: [_marcobambini](https://twitter.com/_marcobambini)
* Email: [marco@creolabs.com](mailto:marco@creolabs.com)
