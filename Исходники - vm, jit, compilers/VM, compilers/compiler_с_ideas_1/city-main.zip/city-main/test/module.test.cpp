#include <gtest/gtest.h>
#include <ir/IRModule.h>

TEST(IRModule, Create)
{
    city::IRModule module{"test"};
}
