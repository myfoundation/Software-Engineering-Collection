#ifndef X86ADDMI32INST_H
#define X86ADDMI32INST_H

#include "backend/amd64/instruction/Amd64Instruction.h"

namespace city
{
    class Amd64AddMI32Inst : public Amd64Instruction
    {
    };
} // namespace city

#endif // X86ADDMI32INST_H
