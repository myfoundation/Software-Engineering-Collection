
#include "Amd64Register.h"

using namespace city;

Amd64Register::Amd64Register(Amd64RegisterCode code) : code_(code) {}
