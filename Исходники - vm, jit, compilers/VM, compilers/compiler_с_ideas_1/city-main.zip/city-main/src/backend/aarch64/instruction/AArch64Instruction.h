#ifndef CITY_AARCH64INSTRUCTION_H
#define CITY_AARCH64INSTRUCTION_H

namespace city
{
    class AArch64Instruction
    {

    };
} // city

#endif //CITY_AARCH64INSTRUCTION_H
