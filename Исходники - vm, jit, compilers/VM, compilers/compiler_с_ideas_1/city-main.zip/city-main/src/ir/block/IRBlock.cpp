
#include "IRBlock.h"

using namespace city;

IRBlock::IRBlock(IRFunction &parent_function) : parent_function_(parent_function) {}
