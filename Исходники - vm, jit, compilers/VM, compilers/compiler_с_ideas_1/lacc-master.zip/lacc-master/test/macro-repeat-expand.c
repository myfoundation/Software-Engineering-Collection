#define __STD_TYPE		
#define __UQUAD_TYPE unsigned long int
#define __DEV_T_TYPE __UQUAD_TYPE

__STD_TYPE __UQUAD_TYPE __dev_t;

int main(void) {
	return 0;
}
