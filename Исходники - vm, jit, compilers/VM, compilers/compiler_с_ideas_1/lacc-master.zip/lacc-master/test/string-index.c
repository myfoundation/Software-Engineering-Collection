int main(void) {
	char a = "Hello"[2];
	char b = 2["World"];
	return a + b;
}
