int g = -1L;
unsigned char i = 0;

int main () {
	unsigned char c = 0xff;
	int d = -1;
	return (c == d) + (i >= g);
}
