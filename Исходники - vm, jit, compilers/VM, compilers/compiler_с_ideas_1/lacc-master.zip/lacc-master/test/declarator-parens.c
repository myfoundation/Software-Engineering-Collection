static int ((foo))(int wat) {
	return wat;
}

int main(void) {
	return foo(42);
}
