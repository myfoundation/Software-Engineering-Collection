int main(void) {
	float f = 3.14;
	double d = 2.71f;

	d = f;

	return d;
}
