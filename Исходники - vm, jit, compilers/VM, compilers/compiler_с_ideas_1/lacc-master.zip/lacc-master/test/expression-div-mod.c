int main() {
	int a = 3, b = 2;
	long c = 6;

	int d = a / b;
	int e = a % b;
	int f = a / c;

	return d + e + f;
}
