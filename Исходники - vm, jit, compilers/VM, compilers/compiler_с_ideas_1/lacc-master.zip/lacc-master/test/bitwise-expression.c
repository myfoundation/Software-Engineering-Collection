int g = 0xEB0647DCL;

int main(void) {
	int i = (0xEB0647DCL < (g | 0x4B54C5F6B4AB19F8LL));
	return i;
}
