int reg(int a) {
	return a;
}

int main(void) {
	int t = 1;
	return reg(t);
}
