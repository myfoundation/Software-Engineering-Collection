int main(void) {
	float f1 = 3.14f, f2;

	f2 = (double) f1 - 2;

	return f2;
}
