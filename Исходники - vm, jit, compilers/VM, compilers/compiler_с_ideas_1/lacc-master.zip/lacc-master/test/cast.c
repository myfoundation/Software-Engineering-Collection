int main(void) {
	char arr[] = {1, 2, 3, 4};
	char *ptr = (char *) arr;

	return (int) *ptr;
}
