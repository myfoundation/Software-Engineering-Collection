int f = 0, g;
long h = 42l;

int main(void) {
	f < 0L;
	if (h) {
		g = 2;
	} else {
		g = 1;
	}
	return g;
}
