char foo[] = "Foo";
char *bar = "Bar";

int main() {
	char c = *foo;
	char d = *bar;
 
	return c + d;
}
