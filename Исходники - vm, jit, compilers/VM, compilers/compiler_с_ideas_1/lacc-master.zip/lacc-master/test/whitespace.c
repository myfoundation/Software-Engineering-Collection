int puts(const char *);

 /* form feed, 0x0c */

int main(void) {
	return puts("Hello");
}
