int printf(const char *, ...);

// Hello!
// */

char *str = "a\"/*b";
char c = '"';

//\
foo();

/\
/ bar();

int foo(int a, int b) {
//
	int f = a/**//b;
	int g = a//**/o
		+ b;
	return printf("%d, %d, %s, %s, %d\n", f, g, "w // t", str, c);
}

int main(void) {// \ to\do
	return /*//*/ foo(__LINE__ * 2, 2);;
}
