int main(void) {
	int i = 42;
}
