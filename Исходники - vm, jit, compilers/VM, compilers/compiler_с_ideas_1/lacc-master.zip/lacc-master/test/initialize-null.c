#define NULL (void *) 0

char *str = NULL;

int main(void) {
	return 0;
}
