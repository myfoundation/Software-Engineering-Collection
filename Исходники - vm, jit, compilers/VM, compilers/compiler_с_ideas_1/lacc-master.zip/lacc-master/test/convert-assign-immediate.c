int printf(const char *, ...);

int main(void) {
	int x;
	x = 2.2f;
	return printf("%d\n", x);
}
