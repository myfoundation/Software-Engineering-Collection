int main() {
	char c = 0xff;
	unsigned int d = 4;

	return c >= d;
}
