int main(void) {
	unsigned char *b = "b2";
	signed char *w = "w3";
	return b[1] + w[1];
}
