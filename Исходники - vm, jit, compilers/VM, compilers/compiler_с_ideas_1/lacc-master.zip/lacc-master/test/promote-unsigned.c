int main() {
    unsigned int ui = 12;
    unsigned long ul = 34;

    return ui + ul;
}
