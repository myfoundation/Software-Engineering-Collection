int main() {
    char c[2] = {1, 2};
    return 1[c];
}
