int puts(const char *);

char hello[] = "Hello World!";

char *how = "How are you?";

long demo, ret = 42;

int main(int argc, char *argv[])
{
	puts(hello);
	puts(how);
	return ret;
}
