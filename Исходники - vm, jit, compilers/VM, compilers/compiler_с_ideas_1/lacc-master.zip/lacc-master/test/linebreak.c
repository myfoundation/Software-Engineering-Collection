/\
*
*/ # /*
*\
/ defi\
ne FO\
O 1\
2

int main() {
	return FOO;
}
