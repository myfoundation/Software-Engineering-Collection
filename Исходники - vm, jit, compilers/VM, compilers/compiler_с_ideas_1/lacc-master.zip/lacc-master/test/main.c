int main() {
	int a;
	a = 42;
	return a;
}
