int main()
{
	int a = 0x01, b = 0x02;

	return a && b;
}
