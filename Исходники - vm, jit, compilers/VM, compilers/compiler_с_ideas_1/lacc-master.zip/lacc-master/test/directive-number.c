#if 'A' == '\301'
#error Wrong
#endif

int main(void) {
	return '\301';
}
