#ifndef DWARF_H
#define DWARF_H

INTERNAL int dwarf_init(const char *filename);

INTERNAL int dwarf_flush(void);

#endif
