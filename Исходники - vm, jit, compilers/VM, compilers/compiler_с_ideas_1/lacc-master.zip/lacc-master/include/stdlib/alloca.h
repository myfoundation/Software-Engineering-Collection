#ifndef _ALLOCA_H
#define _ALLOCA_H

#define alloca(n) __builtin_alloca(n)

#endif
