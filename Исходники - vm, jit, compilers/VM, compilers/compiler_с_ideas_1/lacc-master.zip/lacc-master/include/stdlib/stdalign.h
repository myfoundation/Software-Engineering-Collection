#ifndef _STDALIGN_H
#define _STDALIGN_H

#define alignof _Alignof

#endif
