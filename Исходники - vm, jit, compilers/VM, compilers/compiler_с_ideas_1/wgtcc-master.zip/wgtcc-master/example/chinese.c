#include <stdio.h>
#include <stdlib.h>

#define 整型    int
#define 输出    printf
#define 面函数  main
#define 返回    return
#define 定义    typedef
#define 不可变  const
#define 字符    char
#define 指针    *
#define 为

定义 不可变 字符 指针 为 字面值;

整型 面函数() {
  字面值 蛤蛤 = "\u82df\u5229\u56fd\u5bb6\u751f\u6b7b\u4ee5\uff0c"
               "\u5c82\u56e0\u7978\u798f\u907f\u8d8b\u4e4b";
  输出("%s\n", 蛤蛤);
  返回 0;
}
