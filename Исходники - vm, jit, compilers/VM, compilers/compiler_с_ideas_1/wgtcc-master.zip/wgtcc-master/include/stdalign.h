#ifndef _WGTCC_STDALIGN_H_
#define _WGTCC_STDALIGN_H_

#define alignas _Alignas
#define alignof _Alignof
#define __alignas_is_defined 1
#define __alignof_is_defined 1

#endif
