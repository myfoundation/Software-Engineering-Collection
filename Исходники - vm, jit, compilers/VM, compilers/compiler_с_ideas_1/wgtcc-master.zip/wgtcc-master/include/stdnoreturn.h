#ifndef _WGTCC_STDNORETURN_H_
#define _WGTCC_STDNORETURN_H_

#define noreturn _Noreturn

#endif
