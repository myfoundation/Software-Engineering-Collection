#include_next "math.h"

int flash;
