// @wgtcc: passed

#include <assert.h>
#if !__STDC_NO_COMPLEX__
#include <complex.h>
#endif
#include <ctype.h>
#include <errno.h>
#include <fenv.h>
#include <float.h>
#include <inttypes.h>
#include <iso646.h>
#include <limits.h>
#include <locale.h>
#include <math.h>
#include <setjmp.h>
#include <signal.h>
#include <stdalign.h>
#include <stdarg.h>
#if !__STDC_NO_ATOMICS__
#include <stdatomic.h>
#endif
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#if !__STDC_NO_COMPLEX__
#include <tgmath.h>
#endif
#if !__STDC_NO_THREADS__
#include <threads.h>
#endif
#include <time.h>
#include <uchar.h>
#include <wchar.h>
#include <wctype.h>

int main() {
  return 0;
}
