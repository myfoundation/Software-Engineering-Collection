#include_next "math.h"
int bar;
