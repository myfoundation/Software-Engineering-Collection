/* Copyright Abandoned 1996,1999 TCX DataKonsult AB & Monty Program KB & Detron HB
   This file is public domain and comes with NO WARRANTY of any kind */

/* Version numbers for protocol & mysqld */

#define MYSQL_SERVER_VERSION		"3.23.10-alpha"
#define FRM_VER				6
#define MYSQL_VERSION_ID		32310
/* mysqld compile time options */
#define MYSQL_CHARSET			"latin1"
