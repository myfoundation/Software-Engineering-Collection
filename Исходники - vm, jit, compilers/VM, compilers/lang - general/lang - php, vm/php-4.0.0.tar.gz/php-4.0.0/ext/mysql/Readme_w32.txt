MySQL Extension for PHP 4.0 - Win32 README
------------------------------------------

In order to compile this extension, MySQL must be installed in a parrallel directory
to that of PHP 4.0.  For example, if you have PHP 4.0's source tree set up in
C:\Projects\php4, you must have MySQL set up in C:\Projects\MySQL.  The compiler
will look for include files in C:\Projects\MySQL\include and for the library
files in C:\Projects\MySQL\lib.

You can change this by editing the project settings, but it's not recommended, since
you will have to do it every time you obtain a new version of the PHP 4.0 source tree.


[4/6/1999 zeev@zend.com]