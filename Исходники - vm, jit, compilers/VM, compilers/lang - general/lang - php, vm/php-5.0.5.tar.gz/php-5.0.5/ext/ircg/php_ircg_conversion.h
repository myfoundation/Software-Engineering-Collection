void php_ircg_js_escape(smart_str *input, smart_str *output);
void php_ircg_nickname_escape(smart_str *input, smart_str *output);
void php_ircg_nickname_unescape(smart_str *input, smart_str *output);

