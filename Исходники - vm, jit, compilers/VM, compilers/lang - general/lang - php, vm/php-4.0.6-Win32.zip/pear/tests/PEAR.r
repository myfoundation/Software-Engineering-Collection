test class __TestPEAR1
PEAR constructor called, class=__testpear1
string(11) "__testpear1"
