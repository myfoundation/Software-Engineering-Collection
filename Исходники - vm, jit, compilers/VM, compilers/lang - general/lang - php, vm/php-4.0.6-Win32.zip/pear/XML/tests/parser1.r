new __TestParser1 string(13) "__testparser1"
parseString <ROOT><![CDATA[foo]]></ROOT>
bool(true)
