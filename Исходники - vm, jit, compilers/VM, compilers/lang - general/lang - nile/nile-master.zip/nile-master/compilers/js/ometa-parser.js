Parser = objectThatDelegatesTo(OMeta, {
})

