# Ohm Visualizer

The visualizer is a work in progress. For now, the visualizer only runs on
a grammar and input that is hardcoded in index.html. Eventually, it should
have a command line which works identically to the regular Ohm command line.

To run the debugger, just open `visualizer/index.html` in your browser. For
development, use `bin/ohm-visualizer` which opens the visualizer and enables
live reloading whenever `dist/ohm.js` or any of the files in the `visualizer`
directory are changed.
