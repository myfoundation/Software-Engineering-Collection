# RoomDB

RoomDB is a Datalog-style database inspired by the implementation of the [Dynamicland](https://dynamicland.org/) project. It enables programmers to represent facts using natural language, with a syntax adapted from my [NL-Datalog project](https://github.com/harc/nl-datalog).

## TODO

* Add documentation, examples, etc.
