TODO
====

* samples vs. wishes

* evidence

* include "world time" in samples

* factor common code from LocalClient and RemoteClient into AbstractClient

* be more careful with client IDs
  (e.g., to prevent 2 clients from having the same ID)

* consider space-insensitive matching for facts
  (would need a canonical representation to use as keys for factMap)

* think about "primary keys"?
