#!/bin/bash
php php.php "$@"
