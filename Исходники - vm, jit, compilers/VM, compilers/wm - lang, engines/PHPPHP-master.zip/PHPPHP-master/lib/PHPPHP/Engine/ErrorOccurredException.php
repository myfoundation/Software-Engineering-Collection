<?php

namespace PHPPHP\Engine;

class ErrorOccurredException extends \Exception {
    
}