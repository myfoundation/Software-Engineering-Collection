<?php

namespace PHPPHP\SAPI\CLI;

class SAPI implements \PHPPHP\SAPI {
    
    public function run() {
    }

}