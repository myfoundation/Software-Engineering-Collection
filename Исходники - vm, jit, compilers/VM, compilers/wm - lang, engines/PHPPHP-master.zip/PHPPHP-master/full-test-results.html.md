<h2>Time Start: 2013-03-07 14:20:31</h2>
<table>
<tr><td>PASS</td><td>Trivial "Hello World" test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Simple POST Method test</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>GET and POST Method combined</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Two variables in POST data</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Three variables in POST data</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Add 3 variables together and print result</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Multiply 3 variables and print result</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Divide 3 variables and print result</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Subtract 3 variables and print result</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Testing | and & operators</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Testing $argc and $argv handling (GET)</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Testing $argc and $argv handling (cli)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>POST Method test and arrays</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>POST Method test and arrays - 2</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>POST Method test and arrays - 3</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>POST Method test and arrays - 4</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>POST Method test and arrays - 5</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>POST Method test and arrays - 6</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>POST Method test and arrays - 7</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>POST Method test and arrays - 8</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Bug #37276 (problems witch $_POST array)</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Cookies test#1</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Cookies test#2</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Test HTTP_RAW_POST_DATA creation</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Test HTTP_RAW_POST_DATA with excessive post length</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Registration of HTTP_RAW_POST_DATA due to unknown content-type</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Handling of max_input_nesting_level being reached</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>RFC1867 character quotting</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Shift_JIS request</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Bug#55504 (Content-Type header is not parsed correctly on HTTP POST request)</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Bug#55504 (Content-Type header is not parsed correctly on HTTP POST request)</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Bug#18792 (no form variables after multipart/form-data)</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>WARN&FAIL</td><td>Bug #20539 (PHP CLI Segmentation Fault)</td><td> (warn: ing: unlink(/Users/anthony/Dropbox/WorkNetbeans/PHP-PHP/vendor/php/php-src/tests/basic/sess_): No such file or directory in /Users/anthony/Dropbox/WorkNetbeans/PHP-PHP/lib/PHPPHP/Engine/FunctionData/InternalProxy.php on line 19)</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #29971 (variables_order behaviour)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #45986 (wrong error message for a non existant file on rename)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #51709 (Can't use keywords as method names)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #51709 (Can't use keywords as method names)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Bug #53180 (post_max_size=0 partly not working)</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Req #54514 (Get php binary path during script execution)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Bug #55500 (Corrupted $_FILES indices lead to security concern)</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Bug #61000 (Exceeding max nesting level doesn't delete numerical vars)</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>enable_post_data_reading: basic test</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>enable_post_data_reading: rfc1867</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>enable_post_data_reading: always_populate_raw_post_data has no effect (1)</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>enable_post_data_reading: always_populate_raw_post_data has no effect (2)</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Req #44164 (Handle "Content-Length" HTTP header when zlib.output_compression active)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>rfc1867 anonymous upload</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>rfc1867 array upload</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>rfc1867 boundary 1</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>rfc1867 boundary 2</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>rfc1867 empty upload</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>rfc1867 file_upload disabled</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>rfc1867 garbled mime headers</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>rfc1867 invalid boundary</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>rfc1867 malicious input</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>rfc1867 MAX_FILE_SIZE</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>rfc1867 max_file_uploads - empty files shouldn't count (non-debug version)</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>rfc1867 max_file_uploads - empty files shouldn't count (debug version)</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>rfc1867 missing boundary</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>rfc1867 missing boundary 2</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>rfc1867 post_max_filesize</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>rfc1867 post_max_size</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 __call()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 __call() signature check</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Force pass-by-reference to __call</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>When __call() is invoked via ::, ensure current scope's __call() is favoured over the specified class's  __call().</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>When __call() is invoked via ::, ensure private implementation of __call() in superclass is accessed without error.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure exceptions are handled properly when thrown in __call.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure exceptions are handled properly when thrown in a statically declared __call.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 __set() and __get()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 __get() signature check</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 __set() signature check</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 __set() and __get()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 __set() and __get()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 Data corruption in __set</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 An abstract method may not be called</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 An abstract method may not be called</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 An abstract method may not be called</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 An abstract class cannot be instantiated</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A derived class with an abstract method must be abstract</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A final method cannot be abstract</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A class that inherits an abstract method is abstract</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 An abstract class must be declared abstract</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A method cannot be redeclared abstract</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A static abstract methods</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 An abstrcat method cannot be called indirectly</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 ArrayAccess</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 ArrayAccess::offsetSet without return</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 ArrayAccess::offsetGet ambiguties</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 ArrayAccess::offsetGet ambiguties</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 ArrayAccess and sub Arrays</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 ArrayAccess and ASSIGN_OP operators (+=)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 ArrayAccess and [] assignment</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 ArrayAccess and ASSIGN_OP operators (.=)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 ArrayAccess and ArrayProxyAccess, ArrayProxy</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 ArrayAccess and ArrayReferenceProxy with references</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 ArrayAccess and ArrayAccessReferenceProxy with references to main array</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 ArrayAccess cannot assign by reference</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 ArrayAccess and exceptions</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure that ArrayObject acts like an array</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 assign_op property of overloaded object</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 Autoload and class_exists</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 Autoload and get_class_methods</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 Autoload and derived classes</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 Autoload and recursion</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 Autoload from destructor</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 Autoload from destructor</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure instanceof does not trigger autoload.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure catch blocks for unknown exception types do not trigger autoload.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Ensure type hints for unknown types do not trigger autoload.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure implements does trigger autoload.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure extends does trigger autoload.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure callback methods in unknown classes trigger autoload.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Ensure the ReflectionClass constructor triggers autoload.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Ensure the ReflectionMethod constructor triggers autoload.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Ensure the ReflectionProperty constructor triggers autoload.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Ensure ReflectionClass::getProperty() triggers autoload</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Ensure ReflectionClass::implementsInterface triggers autoload.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure __autoload() allows for recursive calls if the class name differs.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure __autoload() recursion is guarded for multiple lookups of same class using difference case.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure __autoload() is triggered during unserialization.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #23951 (Defines not working in inherited classes)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #24399 (is_subclass_of() crashes when parent class doesn't exist)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #24445 (get_parent_class() returns the current class when passed an object)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #26737 (Protected and private variables are not saved on serialization when a user defined __sleep is used)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #27468 (foreach in __destruct() causes segfault)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #27504 (call_user_func_array allows calling of private/protected methods)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #29446 (ZE allows multiple declarations of the same class constant)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 An abstract class cannot be instanciated</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Classes general test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A final class cannot be inherited</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Instantiate stdClass</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 object cloning, 1</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 object cloning, 2</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 object cloning, 3</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 object cloning, 4</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 object cloning, 5</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 object cloning, 6</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Class constant declarations</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Basic class support - defining and reading a class constant.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure class properties and constants can be defined in terms of constants that are not known at compile time.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test properties with array default values using class constants as keys and values.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test constants with default values based on other constants.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure class constants are not evaluated when a class is looked up to resolve inheritance during runtime.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Error case: duplicate class constant definition</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Error case: class constant as an array</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Basic class support - attempting to pass a class constant by reference.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Class constant whose initial value refereces a non-existent class</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Error case: class constant as an encapsed containing a variable</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Basic class support - attempting to modify a class constant by assignment</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Basic class support - attempting to create a reference to a class constant</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 class constants and scope</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 The new constructor/destructor is called</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A derived class can use the inherited constructor/destructor</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 Do not call destructors if constructor fails</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A class constructor must keep the signature of an interface</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A class constructor must keep the signature of all interfaces</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A class constructor must keep the signature of base class interfaces</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A class constructor must keep the signature of base class interfaces</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 The child class can re-use the parent class name for a function member</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A private constructor cannot be called</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 dereferencing of objects from methods</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 Destructors and echo</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 catch exception thrown in destructor</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 accessing globals from destructor in shutdown</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 Destructing and references</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 The inherited destructor is called</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 Ensuring destructor visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 Ensuring destructor visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 Ensuring destructor visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 factory objects</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 factory and singleton, test 1</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 factory and singleton, test 2</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 factory and singleton, test 3</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 factory and singleton, test 4</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 factory and singleton, test 5</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 factory and singleton, test 6</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 factory and singleton, test 7</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 factory and singleton, test 8</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 factory and singleton, test 9</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 factory and singleton, test 10</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 A method may be redeclared final</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A final method cannot be abstract</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 cannot override final __construct</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 cannot override final old style ctor</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure implicit final inherited old-style constructor cannot be overridden.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A final method may not be overwritten</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Implicit object instantiation when accessing properties of non-object.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 post increment/decrement property of overloaded object</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 post increment/decrement property of overloaded object with assignment</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 pre increment/decrement property of overloaded object</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 pre increment/decrement property of overloaded object with assignment</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Classes inheritance test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 Constructor precedence</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 method inheritance without interfaces</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 method inheritance without interfaces</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Check for inherited old-style constructor.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Private property inheritance check</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure inherited old-style constructor doesn't block other methods</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 a class cannot extend an interface</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A class can only implement interfaces</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure an interface may not shadow an inherited constant.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure a class may not shadow a constant inherited from an interface.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure a class may not inherit two constants with the same name from two separate interfaces.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure a class may implement two interfaces which include the same constant (due to inheritance).</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 An interface extends base interfaces</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 An interface is inherited</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 An interface cannot be instantiated</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 An interface cannot have properties</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 An interface method must be abstract</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 An interface method cannot be final</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 An interface method cannot be private</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 An interface must be implemented</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 An interface method allows additional default arguments</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>default argument value in interface implementation</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>default argument value in and in implementing class with interface in included file</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 interfaces</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 interface with an unimplemented method</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 interface and __construct</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 iterators and foreach</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 iterators and break</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 iterators and break</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 iterators must be implemented</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 iterators cannot implement Traversable alone</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 iterators and array wrapping</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 iterators and exceptions</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure plain userspace superclass does not override special iterator behaviour on child class.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>In $a->$b[Y](), $b[Y] represents a method name on $a. But in $a->X[Y](), $a->X[Y] represents a global function name.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Method override allows optional default argument</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Omitting optional arg in method inherited from abstract class</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Confirm difference between assigning new directly and by reference.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 object references</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A private method can only be called inside the class</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A private method cannot be called in another class</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A private method cannot be called in a derived class</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A private method cannot be called in a derived class</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A private method cannot be called in a derived class</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A private method cannot be called in a derived class</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A private method cannot be called in a derived class</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A private method cannot be called in a derived class</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A private method can be overwritten in a second derived class</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A private method can be overwritten in a second derived class</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A derived class does not know about privates of ancestors</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A derived class does not know about privates of ancestors</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A private member is</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A derived class does not know anything about inherited private methods</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited private static property as private.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited private static property as private static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited private static property as protected.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited private static property as protected static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited private static property as public.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited private static property as public static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited private property as private.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited private property as private static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited private property as protected.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited private property as protected static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited private property as public.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited private property as public static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited protected static property as private.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited protected static property as private static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited protected static property as protected.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited protected static property as protected static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited protected static property as public.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited protected static property as public static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited protected property as private (duplicates Zend/tests/errmsg_023.phpt).</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited protected property as private static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited protected property as protected.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited protected property as protected static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited protected property as public.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited protected property as public static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited public static property as private.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited public static property as private static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited public static property as protected.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited public static property as protected static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited public static property as public.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited public static property as public static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited public property as private.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited public property as private static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited public property as protected.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited public property as protected static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited public property as public.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Redeclare inherited public property as public static.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Unsetting and recreating private properties.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Unsetting and recreating protected properties.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A protected method can only be called inside the class</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A protected method can only be called inside the class</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A protected method cannot be called in another class</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 Serializable</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 singleton</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 You cannot overload a static method with a non static method</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 You cannot overload a non static method with a static method</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 Initializing static properties to arrays</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Attempting to access static properties using instance property syntax</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Attempting to access static properties using instance property syntax</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Attempting to access static properties using instance property syntax</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Attempting to access static properties using instance property syntax</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Attempting to access static properties using instance property syntax</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Inherited static properties can be separated from their reference set.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Assigning to a non-existent static property</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Assigning & incrementing a non-existent static property</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Assigning a non-existent static property by reference</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Incrementing a non-existent static property</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Issetting a non-existent static property</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Reading a non-existent static property</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 $this can be an argument to a static function</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 $this cannot be exchanged</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 __toString()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 __toString() in __destruct</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 __toString() in __destruct/exception</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Object to string conversion: error cases and behaviour variations.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 class type hinting</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 class type hinting non existing class</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 class type hinting with arrays</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure type hints are enforced for functions invoked as callbacks.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Check type hint compatibility in overrides with array hints.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Check type hint compatibility in overrides with array hints.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Check type hint compatibility in overrides with array hints.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Check type hint compatibility in overrides with array hints.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Un-setting instance properties causes magic methods to be called when trying to access them from outside the magic
methods themselves.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A redeclared method must have the same or higher visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A redeclared method must have the same or higher visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 A redeclared method must have the same or higher visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A redeclared method must have the same or higher visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A redeclared method must have the same or higher visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 A redeclared method must have the same or higher visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A redeclared method must have the same or higher visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A redeclared method must have the same or higher visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 A redeclared method must have the same or higher visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 A redeclared method must have the same or higher visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 A redeclared method must have the same or higher visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 A redeclared method must have the same or higher visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 A redeclared method must have the same or higher visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 A redeclared method must have the same or higher visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 A redeclared method must have the same or higher visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 foreach and property visibility</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Strlen() function test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Static variables in functions</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>General function test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>General function test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Testing register_shutdown_function()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Testing register_shutdown_function() with timeout. (Bug: #21513)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Output buffering tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>INI functions test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test for buffering in core functions with implicit flush off</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test for buffering in core functions with implicit flush on</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>function with many parameters</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ini_alter() check</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Simple If condition test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Simple While Loop Test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Simple Switch Test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Simple If/Else Test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Simple If/ElseIf/Else Test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Nested If/ElseIf/Else Test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Function call with global and static variables</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Testing recursive function</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Testing function parameter passing</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Testing function parameter passing with a return value</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Testing nested functions</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Testing stack after early function return</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Testing eval function</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Testing eval function inside user-defined function</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Testing include</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Testing user-defined function in included file</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Testing user-defined function falling out of an If into another</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>eval() test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>eval() test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Switch test 1</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Switch test 2</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Switch test 3</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Regression test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Looped regression test (may take a while)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Mean recursion test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Testing string scanner confirmance</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Testing do-while loop</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Testing calling user-level functions from C</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>$this in constructor test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #16227 (Internal hash position bug on assignment)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Class method registration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Alternative syntaxes test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #12647 (Locale settings affecting float parsing)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2: set_exception_handler()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Child public element should not override parent private element in parent methods</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>'Static' binding for private variables</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Convert warnings to exceptions</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Catch Interfaces</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>foreach into array</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Dynamic access of static members</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Dynamic access of constants</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Dynamic call for static methods</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Dynamic call for static methods dynamically named</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Timeout again inside register_shutdown_function</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Square bracket array shortcut test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Square bracket associative array shortcut test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Testing array shortcut and bracket operator</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Testing nested array shortcut</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bison weirdness</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #17115 (lambda functions produce segfault with static vars)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #18872 (class constant used as default parameter)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #19566 (get_declared_classes() segfaults)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #19943 (memleaks)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #20175 (Static vars can't store ref to new instance)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #21094 (set_error_handler not accepting methods)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #21600 (assign by reference function call changes variable contents)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #21669 ("$obj = new $this->var;" doesn't work)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #21820 ("$arr['foo']" generates bogus E_NOTICE, should be E_PARSE)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #21849 (self::constant doesn't work as method's default parameter)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #21961 (get_parent_class() segfault)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #22231 (segfault when returning a global variable by reference)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #22510 (segfault among complex references)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #22592 (cascading assignments to strings with curly braces broken)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #22690 (ob_start() is broken with create_function() callbacks)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #23279 (exception handler stops after first function call)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #23384 (use of class constants in statics)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #23489 (ob_start() is broken with method callbacks)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #23524 (Improper handling of constants in array indices)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #23584 (error line numbers off by one when using #!php)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #23624 (foreach leaves current array key as null)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #23922 (scope doesn't properly propagate into internal functions)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #24054 (Assignment operator *= broken)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #24396 (global $$variable broken)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #24403 (scope doesn't properly propagate into internal functions)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #24436 (isset() and empty() produce errors with non-existent variables in objects)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #24499 (bogus handling of a public property as a private one)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #24573 (debug_backtrace() crashes if $this is set to null)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #24640 (var_export and var_dump can't output large float)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #24652 (broken array_flip())</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #24658 (combo of typehint / reference causes crash)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #24783 ($key not binary safe in "foreach($arr as $key => $val)")</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #24908 (super-globals can not be used in __destruct())</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #24926 (lambda function (create_function()) cannot be stored in a class property)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #24951 (ob_flush() destroys output handler)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Bug #25145 (SEGV on recpt of form input with name like "123[]")</td><td>reason: CGI not available</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #25547 (error_handler and array index with function call)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #25652 (Calling Global functions dynamically fails from Class scope)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #25922 (SEGV in error_handler when context is destroyed)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #26182 (Object properties created redundantly)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #26696 (string index in a switch() crashes with multiple matches)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #26866 (segfault when exception raised in __get)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #26869 (constant as the key of static array)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #27354 (Modulus operator crashes PHP)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #27439 (foreach() with $this segfaults)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #27443 (defined() returns wrong type)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #27535 (Objects pointing to each other cause Apache to crash)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #28213 (crash in debug_print_backtrace in static methods)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #28800 (Incorrect string to number conversion for strings starting with 'inf')</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #29566 (foreach/string handling strangeness)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #29893 (segfault when using array as index)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #29944 (function defined in switch crashes PHP)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #30578 (Output buffers flushed before calling __desctruct functions)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Bug #30638 (localeconv returns wrong LC_NUMERIC settings) (ok to fail on MacOS X)</td><td>reason: ok to fail on MacOS X</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #30726 (-.1 like numbers are not being handled correctly)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #30862 (Static array with boolean indexes)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #32828 (Throwing exception in output_callback function with ob_start and ob_end_clean leads to segfault)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #32924 (prepend does not add file to included files)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #35176 (include()/require()/*_once() produce wrong error messages about main())</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #35382 (Comment in end of file produces fatal error)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Bug #38579 (include_once() may include the same file twice)</td><td>reason: only for Windows</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #43958 (class name added into the error message)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #44654 (syntax error for #)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #44827 (Class error when trying to access :: as constant)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #45392 (ob_start()/ob_end_clean() and memory_limit)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #55754 (Only variables should be passed by reference for ZEND_SEND_PREFER_REF params)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #7515 (weird & invisible referencing of objects)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Catchable fatal error [1]</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Catchable fatal error [2]</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>#-style comments</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>#-style comments (part 2)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test standard 'compare' object handler</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test object compare when object handler different</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Binary safety of each() for both keys and values</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>empty() on array elements</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Evaluation order during assignments.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Evaluation order during assignments.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Evaluation order during assignments.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Evaluation order during assignments.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Evaluation order during assignments.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Evaluation order during assignments.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Check key execution order with &new.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure by value assignments leave temporaries on the stack, for all sorts of assignees.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Execution ordering with comparison operators.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ZE2 errors caught as exceptions</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Execution order of variables</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Foreach loop tests - basic loop with just value and key => value.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Foreach loop tests - modifying the array during the loop.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Foreach loop tests - error case: not an array.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Foreach loop tests - using an array element as the $value</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Foreach loop tests - modifying the array during the loop: special case. Behaviour is good since php 5.2.2.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Foreach loop tests - error case: key is a reference.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Foreach loop tests - foreach operates on the original array if the array is referenced outside the loop.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>This test illustrates the impact of invoking destructors when refcount is decremented to 0 on foreach.
It will pass only if the 'contentious code' in PHPValue.decReferences() is enabled.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Changing from an interable type to a non iterable type during the iteration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Directly modifying an unreferenced array when foreach'ing over it.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Directly modifying an unreferenced array when foreach'ing over it while using &$value syntax.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Directly modifying a REFERENCED array when foreach'ing over it.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Directly modifying a REFERENCED array when foreach'ing over it while using &$value syntax.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Ensure foreach splits the iterated entity from its cow reference set, for all sorts of iterated entities.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Ensure foreach works with arrays with Binary keys.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>foreach with Iterator.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>foreach with iterator and &$value reference</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>foreach with iteratorAggregate</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>IteratorAggregate::getIterator bad return type</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>foreach with nested iteratorAggregates</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Duplicate of zend test tests/classes/iterators_002.phpt without expected output from destructor</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Foreach loop on objects - basic loop with just value and key => value.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Foreach loop tests - visibility.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Foreach loop tests - modifying the object during the loop.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Foreach loop tests - Removing the current element from an iterated object.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Foreach loop tests - removing properties before and after the current property during the loop.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Foreach loop tests - substituting the entire iterated entity during the loop.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>foreach() with foreach($o->mthd()->arr)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>foreach() with references</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>func_get_arg test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>func_get_arg with variable number of args</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>func_get_arg outside of a function declaration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>func_get_arg on non-existent arg</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>A variable, which is referenced by another variable, is passed by value.
During the call, the original variable is updated. This should not affect func_get_arg().</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>func_get_arg test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>func_get_args with no args</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>func_get_args with variable number of args</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>func_get_args() outside of a function declaration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Pass same variable by ref and by value.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>func_num_args with no args</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>func_num_args with variable number of args</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>func_num_args() outside of a function declaration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Pass same variable by ref and by value.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>include() a file from the current script directory</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Including a file in the current script directory from an included function</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Including a file in the current script directory from eval'd code</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test + operator : 64bit long tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test + operator : various numbers as strings</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test & operator : 64bit long tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test & operator : various numbers as strings</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test ~N operator : 64bit long tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test ~N operator : various numbers as strings</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test | operator : 64bit long tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test | operator : various numbers as strings</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test << operator : 64bit long tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Test << operator : various numbers as strings</td><td>reason: this test is for 32bit platform only</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test << operator : various numbers as strings</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test >> operator : 64bit long tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test >> operator : various numbers as strings</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test ^ operator : 64bit long tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test ^ operator : various numbers as strings</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test / operator : 64bit long tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test / operator : various numbers as strings</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test % operator : 64bit long tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test % operator : various numbers as strings</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test * operator : 64bit long tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test * operator : various numbers as strings</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test -N operator : 64bit long tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test -N operator : various numbers as strings</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test == operator : different types</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Test == operator : max int 32bit range</td><td>reason: this test is for 32bit platform only</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test == operator : max int 64bit range</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test > operator : different types</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test >= operator : different types</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Test >= operator : max int 32bit range</td><td>reason: this test is for 32bit platform only</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test >= operator : max int 64bit range</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Test > operator : max int 32bit range</td><td>reason: this test is for 32bit platform only</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test > operator : max int 64bit range</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test === operator : different types</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Test === operator : max int 32bit range</td><td>reason: this test is for 32bit platform only</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test === operator : max int 64bit range</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test < operator : different types</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test <= operator : different types</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Test <= operator : max int 32bit range</td><td>reason: this test is for 32bit platform only</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test <= operator : max int 64bit range</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Test < operator : max int 32bit range</td><td>reason: this test is for 32bit platform only</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test < operator : max int 64bit range</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test != operator : different types</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Test != operator : max int 32bit range</td><td>reason: this test is for 32bit platform only</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test == operator : max int 64bit range</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test !== operator : different types</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Test !== operator : max int 32bit range</td><td>reason: this test is for 32bit platform only</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test !== operator : max int 64bit range</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test N-- operator : 64bit long tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test N-- operator : various numbers as strings</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test N++ operator : 64bit long tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test N++ operator : various numbers as strings</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test --N operator : 64bit long tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test --N operator : various numbers as strings</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test ++N operator : 64bit long tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test ++N operator : various numbers as strings</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test - operator : 64bit long tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test - operator : various numbers as strings</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>passing of function parameters by reference</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Attempt to pass a constant by reference</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Implicit initialisation when passing by reference</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>passing the return value from a function by reference</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Pass uninitialised variables by reference and by value to test implicit initialisation.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Pass uninitialised objects and arrays by reference to test implicit initialisation.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Pass function and method calls by reference and by value.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Pass same variable by ref and by value.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Assignement as argument</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Passing assignments by reference</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test pass by reference semantics</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Returning a reference from a function</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Returning a reference from a function.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Returning a reference from a function</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Returning a reference from a static method</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Returning a reference from a method</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Returning a reference from a function via another function</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Returning a reference from a static method via another static method</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Returning a reference from a non-static method via another non-static method</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Returning a references returned by another function</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>&lt;script&gt; tag</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>short_open_tag: On</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>short_open_tag: Off</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>short_open_tag: On, asp_tags: On</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>short_open_tag: Off, asp_tags: Off</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Static keyword - basic tests</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Multiple declarations of the same static variable</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Statics in nested functions & evals.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Static variables in methods & nested functions & evals.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>String conversion with multiple decimal points</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test to catch early assignment of $this</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Catching an exception thrown from an included file</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 type hinting</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 type hinting</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ZE2 type hinting</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #46897: ob_flush() should fail to flush unerasable buffers</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #60282 (Segfault when using ob_gzhandler() with open buffers)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #60321 (ob_get_status(true) no longer returns an array when buffer is empty)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #60322 (ob_get_clean() now raises an E_NOTICE if no buffers exist)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #60768 Output buffer not discarded</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test basic functionality of flush()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test wrong number of arguments for flush() (no impact)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>output buffering - nothing</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>output buffering - ob_start</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>output buffering - ob_flush</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>output buffering - ob_clean</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>output buffering - ob_end_clean</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>output buffering - ob_end_flush</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>output buffering - ob_get_clean</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>output buffering - ob_get_contents</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>output buffering - ob_get_flush</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>output buffering - fatalism</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>output buffering - fatalism</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>output buffering - multiple</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>output buffering - handlers/status</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>output buffering - failure</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>output buffering - failure</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>output buffering - stati</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>output buffering - error message nirvana bug #37714</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>output buffering - ob_list_handlers</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test ob_clean() function : basic functionality</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test ob_clean() function : error conditions</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test return type and value, as well as basic behaviour, for ob_end_clean()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test wrong number of arguments for ob_end_clean()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test ob_end_flush() function : basic functionality</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test ob_end_flush() function : error conditions</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test ob_flush() function : basic functionality</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test ob_flush() function : error conditions</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test return type and value, as well as basic behaviour, of ob_get_clean()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test basic behaviour of ob_get_clean()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test wrong number of arguments for ob_get_clean()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test ob_get_contents() function : basic functionality</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test ob_get_contents() function : error cases</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test return type and value, as well as basic behaviour, of ob_get_length()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test wrong number of arguments for ob_get_length()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test ob_get_level() function : basic functionality</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test ob_get_level() function : error conditions</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ob_get_status() function basic test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test ob_implicit_flush() function : check return value (always null).</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Test ob_implicit_flush() function : ensure implicit flushing does not apply to user buffers.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test ob_implicit_flush() function : wrong number of arguments</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test ob_implicit_flush() function : usage variation</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test return type and value for ob_start()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ob_start(): Check behaviour with various callback return values.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ob_start(): ensure even fatal error test is affected by output buffering.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ob_start() chunk_size: confirm buffer is flushed after any output call that causes its length to equal or exceed chunk_size.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ob_start(): non-static method as static callbacks.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ob_start(): ensure multiple buffer initialization with a single call using arrays is not supported on PHP6 (http://bugs.php.net/42641)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ob_start(): Ensure content of unerasable buffer can be accessed by ob_get_contents().</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ob_start(): Ensure unerasable buffer cannot be erased by ob_clean(), ob_end_clean() or ob_end_flush().</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ob_start(): Ensure unerasable buffer cannot be accessed or erased by ob_get_clean().</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ob_start(): Ensure unerasable buffer cannot be accessed or flushed by ob_get_flush().</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>ob_start(): Ensure unerasable buffer cannot be flushed by ob_flush()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test ob_start() with callbacks in variables</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test wrong number of arguments and wrong arg types for ob_start()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test wrong number of arguments and wrong arg types for ob_start()</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test ob_start() with object supplied but no method.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test ob_start() with non existent callback method.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>ob_start(): ensure buffers can't be added from within callback.</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>EXPECT</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>EXPECTF</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>EXPECTREGEX</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>INI section allows '='</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Error message handling (without ZendOptimizer)</td><td>reason: Zend Optimizer is loaded</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Error messages are shown</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>dirname test</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Error message handling (with ZendOptimizer)</td><td>reason: Zend Optimizer is not loaded</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Error message handling (without ZendOptimizer)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>print_r(Object)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>STDIN input</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #53226 (file_exists fails on big filenames)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>openbase_dir runtime tightning</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration for glob</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>XFAIL</td><td>Test open_basedir configuration</td><td>  XFAIL REASON: BUG: open_basedir cannot delete symlink to prohibited file. See also
bugs 48111 and 52176.</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Test open_basedir configuration</td><td>reason: Windows only variation</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Test open_basedir configuration</td><td>reason: Windows only variation</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>SKIP</td><td>Test open_basedir configuration</td><td>reason: only run on Windows</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Test open_basedir configuration</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>String functions</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Formatted print functions</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>highlight_string() buffering</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>Bug #22592 (Cascading assignments to strings with curly braces broken)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>Bug #26703 (Certain characters inside strings incorrectly treated as keywords)</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>testing the behavior of string offset chaining</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>PASS</td><td>testing the behavior of string offset chaining</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>testing the behavior of string offset chaining</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>testing the behavior of string offset chaining</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>testing the behavior of string offset chaining</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>FAIL</td><td>testing the behavior of string offsets</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
</table>
<h2>Time End: 2013-03-07 14:26:59</h2>
<hr/>
<pre>

Number of tests :  754               684
Tests skipped   :   70 (  9.3%) --------
Tests warned    :    1 (  0.1%) (  0.1%)
Tests failed    :  457 ( 60.6%) ( 66.8%)
Expected fail   :    1 (  0.1%) (  0.1%)
Tests passed    :  225 ( 29.8%) ( 32.9%)
---------------------------------------------------------------------
Time taken      :  388 seconds
=====================================================================

=====================================================================
EXPECTED FAILED TEST SUMMARY
---------------------------------------------------------------------
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_linkinfo.phpt]  XFAIL REASON: BUG: open_basedir cannot delete symlink to prohibited file. See also
bugs 48111 and 52176.
=====================================================================

=====================================================================
FAILED TEST SUMMARY
---------------------------------------------------------------------
Testing $argc and $argv handling (cli) [vendor/php/php-src/tests/basic/012.phpt]
Bug #20539 (PHP CLI Segmentation Fault) [vendor/php/php-src/tests/basic/bug20539.phpt] (warn: ing: unlink(/Users/anthony/Dropbox/WorkNetbeans/PHP-PHP/vendor/php/php-src/tests/basic/sess_): No such file or directory in /Users/anthony/Dropbox/WorkNetbeans/PHP-PHP/lib/PHPPHP/Engine/FunctionData/InternalProxy.php on line 19)
Bug #29971 (variables_order behaviour) [vendor/php/php-src/tests/basic/bug29971.phpt]
Bug #45986 (wrong error message for a non existant file on rename) [vendor/php/php-src/tests/basic/bug45986.phpt]
Bug #51709 (Can't use keywords as method names) [vendor/php/php-src/tests/basic/bug51709_1.phpt]
Bug #51709 (Can't use keywords as method names) [vendor/php/php-src/tests/basic/bug51709_2.phpt]
Req #54514 (Get php binary path during script execution) [vendor/php/php-src/tests/basic/bug54514.phpt]
ZE2 __call() [vendor/php/php-src/tests/classes/__call_001.phpt]
ZE2 __call() signature check [vendor/php/php-src/tests/classes/__call_002.phpt]
Force pass-by-reference to __call [vendor/php/php-src/tests/classes/__call_003.phpt]
When __call() is invoked via ::, ensure current scope's __call() is favoured over the specified class's  __call(). [vendor/php/php-src/tests/classes/__call_004.phpt]
When __call() is invoked via ::, ensure private implementation of __call() in superclass is accessed without error. [vendor/php/php-src/tests/classes/__call_005.phpt]
Ensure exceptions are handled properly when thrown in __call. [vendor/php/php-src/tests/classes/__call_006.phpt]
Ensure exceptions are handled properly when thrown in a statically declared __call. [vendor/php/php-src/tests/classes/__call_007.phpt]
ZE2 __set() and __get() [vendor/php/php-src/tests/classes/__set__get_001.phpt]
ZE2 __get() signature check [vendor/php/php-src/tests/classes/__set__get_002.phpt]
ZE2 __set() signature check [vendor/php/php-src/tests/classes/__set__get_003.phpt]
ZE2 __set() and __get() [vendor/php/php-src/tests/classes/__set__get_005.phpt]
ZE2 Data corruption in __set [vendor/php/php-src/tests/classes/__set_data_corrupt.phpt]
ZE2 An abstract method may not be called [vendor/php/php-src/tests/classes/abstract.phpt]
ZE2 An abstract method may not be called [vendor/php/php-src/tests/classes/abstract_by_interface_001.phpt]
ZE2 An abstract method may not be called [vendor/php/php-src/tests/classes/abstract_by_interface_002.phpt]
ZE2 An abstract class cannot be instantiated [vendor/php/php-src/tests/classes/abstract_class.phpt]
ZE2 A derived class with an abstract method must be abstract [vendor/php/php-src/tests/classes/abstract_derived.phpt]
ZE2 A final method cannot be abstract [vendor/php/php-src/tests/classes/abstract_final.phpt]
ZE2 A class that inherits an abstract method is abstract [vendor/php/php-src/tests/classes/abstract_inherit.phpt]
ZE2 An abstract class must be declared abstract [vendor/php/php-src/tests/classes/abstract_not_declared.phpt]
ZE2 A method cannot be redeclared abstract [vendor/php/php-src/tests/classes/abstract_redeclare.phpt]
ZE2 A static abstract methods [vendor/php/php-src/tests/classes/abstract_static.phpt]
ZE2 An abstrcat method cannot be called indirectly [vendor/php/php-src/tests/classes/abstract_user_call.phpt]
ZE2 ArrayAccess [vendor/php/php-src/tests/classes/array_access_001.phpt]
ZE2 ArrayAccess::offsetSet without return [vendor/php/php-src/tests/classes/array_access_002.phpt]
ZE2 ArrayAccess::offsetGet ambiguties [vendor/php/php-src/tests/classes/array_access_003.phpt]
ZE2 ArrayAccess::offsetGet ambiguties [vendor/php/php-src/tests/classes/array_access_004.phpt]
ZE2 ArrayAccess and sub Arrays [vendor/php/php-src/tests/classes/array_access_005.phpt]
ZE2 ArrayAccess and ASSIGN_OP operators (+=) [vendor/php/php-src/tests/classes/array_access_006.phpt]
ZE2 ArrayAccess and [] assignment [vendor/php/php-src/tests/classes/array_access_007.phpt]
ZE2 ArrayAccess and ASSIGN_OP operators (.=) [vendor/php/php-src/tests/classes/array_access_008.phpt]
ZE2 ArrayAccess and ArrayProxyAccess, ArrayProxy [vendor/php/php-src/tests/classes/array_access_009.phpt]
ZE2 ArrayAccess and ArrayReferenceProxy with references [vendor/php/php-src/tests/classes/array_access_010.phpt]
ZE2 ArrayAccess and ArrayAccessReferenceProxy with references to main array [vendor/php/php-src/tests/classes/array_access_011.phpt]
ZE2 ArrayAccess cannot assign by reference [vendor/php/php-src/tests/classes/array_access_012.phpt]
ZE2 ArrayAccess and exceptions [vendor/php/php-src/tests/classes/array_access_013.phpt]
Ensure that ArrayObject acts like an array [vendor/php/php-src/tests/classes/arrayobject_001.phpt]
ZE2 assign_op property of overloaded object [vendor/php/php-src/tests/classes/assign_op_property_001.phpt]
ZE2 Autoload and class_exists [vendor/php/php-src/tests/classes/autoload_001.phpt]
ZE2 Autoload and get_class_methods [vendor/php/php-src/tests/classes/autoload_002.phpt]
ZE2 Autoload and derived classes [vendor/php/php-src/tests/classes/autoload_003.phpt]
ZE2 Autoload and recursion [vendor/php/php-src/tests/classes/autoload_004.phpt]
ZE2 Autoload from destructor [vendor/php/php-src/tests/classes/autoload_005.phpt]
ZE2 Autoload from destructor [vendor/php/php-src/tests/classes/autoload_006.phpt]
Ensure instanceof does not trigger autoload. [vendor/php/php-src/tests/classes/autoload_007.phpt]
Ensure catch blocks for unknown exception types do not trigger autoload. [vendor/php/php-src/tests/classes/autoload_008.phpt]
Ensure implements does trigger autoload. [vendor/php/php-src/tests/classes/autoload_010.phpt]
Ensure extends does trigger autoload. [vendor/php/php-src/tests/classes/autoload_011.phpt]
Ensure callback methods in unknown classes trigger autoload. [vendor/php/php-src/tests/classes/autoload_012.phpt]
Ensure __autoload() allows for recursive calls if the class name differs. [vendor/php/php-src/tests/classes/autoload_018.phpt]
Ensure __autoload() recursion is guarded for multiple lookups of same class using difference case. [vendor/php/php-src/tests/classes/autoload_019.phpt]
Ensure __autoload() is triggered during unserialization. [vendor/php/php-src/tests/classes/autoload_020.phpt]
Bug #23951 (Defines not working in inherited classes) [vendor/php/php-src/tests/classes/bug23951.phpt]
Bug #26737 (Protected and private variables are not saved on serialization when a user defined __sleep is used) [vendor/php/php-src/tests/classes/bug26737.phpt]
Bug #27468 (foreach in __destruct() causes segfault) [vendor/php/php-src/tests/classes/bug27468.phpt]
Bug #27504 (call_user_func_array allows calling of private/protected methods) [vendor/php/php-src/tests/classes/bug27504.phpt]
Bug #29446 (ZE allows multiple declarations of the same class constant) [vendor/php/php-src/tests/classes/bug29446.phpt]
ZE2 An abstract class cannot be instanciated [vendor/php/php-src/tests/classes/class_abstract.phpt]
ZE2 A final class cannot be inherited [vendor/php/php-src/tests/classes/class_final.phpt]
Instantiate stdClass [vendor/php/php-src/tests/classes/class_stdclass.phpt]
ZE2 object cloning, 1 [vendor/php/php-src/tests/classes/clone_001.phpt]
ZE2 object cloning, 2 [vendor/php/php-src/tests/classes/clone_002.phpt]
ZE2 object cloning, 3 [vendor/php/php-src/tests/classes/clone_003.phpt]
ZE2 object cloning, 4 [vendor/php/php-src/tests/classes/clone_004.phpt]
ZE2 object cloning, 5 [vendor/php/php-src/tests/classes/clone_005.phpt]
ZE2 object cloning, 6 [vendor/php/php-src/tests/classes/clone_006.phpt]
Class constant declarations [vendor/php/php-src/tests/classes/constants_basic_001.phpt]
Basic class support - defining and reading a class constant. [vendor/php/php-src/tests/classes/constants_basic_002.phpt]
Ensure class properties and constants can be defined in terms of constants that are not known at compile time. [vendor/php/php-src/tests/classes/constants_basic_003.phpt]
Test properties with array default values using class constants as keys and values. [vendor/php/php-src/tests/classes/constants_basic_004.phpt]
Test constants with default values based on other constants. [vendor/php/php-src/tests/classes/constants_basic_005.phpt]
Ensure class constants are not evaluated when a class is looked up to resolve inheritance during runtime. [vendor/php/php-src/tests/classes/constants_basic_006.phpt]
Error case: duplicate class constant definition [vendor/php/php-src/tests/classes/constants_error_001.phpt]
Error case: class constant as an array [vendor/php/php-src/tests/classes/constants_error_002.phpt]
Basic class support - attempting to pass a class constant by reference. [vendor/php/php-src/tests/classes/constants_error_003.phpt]
Class constant whose initial value refereces a non-existent class [vendor/php/php-src/tests/classes/constants_error_004.phpt]
ZE2 class constants and scope [vendor/php/php-src/tests/classes/constants_scope_001.phpt]
ZE2 The new constructor/destructor is called [vendor/php/php-src/tests/classes/ctor_dtor.phpt]
ZE2 A derived class can use the inherited constructor/destructor [vendor/php/php-src/tests/classes/ctor_dtor_inheritance.phpt]
ZE2 Do not call destructors if constructor fails [vendor/php/php-src/tests/classes/ctor_failure.phpt]
ZE2 A class constructor must keep the signature of an interface [vendor/php/php-src/tests/classes/ctor_in_interface_01.phpt]
ZE2 A class constructor must keep the signature of all interfaces [vendor/php/php-src/tests/classes/ctor_in_interface_02.phpt]
ZE2 A class constructor must keep the signature of base class interfaces [vendor/php/php-src/tests/classes/ctor_in_interface_03.phpt]
ZE2 A class constructor must keep the signature of base class interfaces [vendor/php/php-src/tests/classes/ctor_in_interface_04.phpt]
ZE2 The child class can re-use the parent class name for a function member [vendor/php/php-src/tests/classes/ctor_name_clash.phpt]
ZE2 A private constructor cannot be called [vendor/php/php-src/tests/classes/ctor_visibility.phpt]
ZE2 Destructors and echo [vendor/php/php-src/tests/classes/destructor_and_echo.phpt]
ZE2 catch exception thrown in destructor [vendor/php/php-src/tests/classes/destructor_and_exceptions.phpt]
ZE2 accessing globals from destructor in shutdown [vendor/php/php-src/tests/classes/destructor_and_globals.phpt]
ZE2 The inherited destructor is called [vendor/php/php-src/tests/classes/destructor_inheritance.phpt]
ZE2 Ensuring destructor visibility [vendor/php/php-src/tests/classes/destructor_visibility_001.phpt]
ZE2 Ensuring destructor visibility [vendor/php/php-src/tests/classes/destructor_visibility_002.phpt]
ZE2 Ensuring destructor visibility [vendor/php/php-src/tests/classes/destructor_visibility_003.phpt]
ZE2 factory and singleton, test 1 [vendor/php/php-src/tests/classes/factory_and_singleton_001.phpt]
ZE2 factory and singleton, test 2 [vendor/php/php-src/tests/classes/factory_and_singleton_002.phpt]
ZE2 factory and singleton, test 3 [vendor/php/php-src/tests/classes/factory_and_singleton_003.phpt]
ZE2 factory and singleton, test 4 [vendor/php/php-src/tests/classes/factory_and_singleton_004.phpt]
ZE2 factory and singleton, test 5 [vendor/php/php-src/tests/classes/factory_and_singleton_005.phpt]
ZE2 factory and singleton, test 6 [vendor/php/php-src/tests/classes/factory_and_singleton_006.phpt]
ZE2 factory and singleton, test 7 [vendor/php/php-src/tests/classes/factory_and_singleton_007.phpt]
ZE2 factory and singleton, test 8 [vendor/php/php-src/tests/classes/factory_and_singleton_008.phpt]
ZE2 factory and singleton, test 9 [vendor/php/php-src/tests/classes/factory_and_singleton_009.phpt]
ZE2 factory and singleton, test 10 [vendor/php/php-src/tests/classes/factory_and_singleton_010.phpt]
ZE2 A final method cannot be abstract [vendor/php/php-src/tests/classes/final_abstract.phpt]
ZE2 cannot override final __construct [vendor/php/php-src/tests/classes/final_ctor1.phpt]
ZE2 cannot override final old style ctor [vendor/php/php-src/tests/classes/final_ctor2.phpt]
Ensure implicit final inherited old-style constructor cannot be overridden. [vendor/php/php-src/tests/classes/final_ctor3.phpt]
ZE2 A final method may not be overwritten [vendor/php/php-src/tests/classes/final_redeclare.phpt]
Implicit object instantiation when accessing properties of non-object. [vendor/php/php-src/tests/classes/implicit_instantiation_001.phpt]
ZE2 post increment/decrement property of overloaded object [vendor/php/php-src/tests/classes/incdec_property_001.phpt]
ZE2 post increment/decrement property of overloaded object with assignment [vendor/php/php-src/tests/classes/incdec_property_002.phpt]
ZE2 pre increment/decrement property of overloaded object [vendor/php/php-src/tests/classes/incdec_property_003.phpt]
ZE2 pre increment/decrement property of overloaded object with assignment [vendor/php/php-src/tests/classes/incdec_property_004.phpt]
Classes inheritance test [vendor/php/php-src/tests/classes/inheritance.phpt]
ZE2 Constructor precedence [vendor/php/php-src/tests/classes/inheritance_002.phpt]
ZE2 method inheritance without interfaces [vendor/php/php-src/tests/classes/inheritance_003.phpt]
ZE2 method inheritance without interfaces [vendor/php/php-src/tests/classes/inheritance_004.phpt]
Check for inherited old-style constructor. [vendor/php/php-src/tests/classes/inheritance_005.phpt]
Private property inheritance check [vendor/php/php-src/tests/classes/inheritance_006.phpt]
Ensure inherited old-style constructor doesn't block other methods [vendor/php/php-src/tests/classes/inheritance_007.phpt]
ZE2 a class cannot extend an interface [vendor/php/php-src/tests/classes/interface_and_extends.phpt]
ZE2 A class can only implement interfaces [vendor/php/php-src/tests/classes/interface_class.phpt]
Ensure an interface may not shadow an inherited constant. [vendor/php/php-src/tests/classes/interface_constant_inheritance_001.phpt]
Ensure a class may not shadow a constant inherited from an interface. [vendor/php/php-src/tests/classes/interface_constant_inheritance_002.phpt]
Ensure a class may not inherit two constants with the same name from two separate interfaces. [vendor/php/php-src/tests/classes/interface_constant_inheritance_003.phpt]
Ensure a class may implement two interfaces which include the same constant (due to inheritance). [vendor/php/php-src/tests/classes/interface_constant_inheritance_004.phpt]
ZE2 An interface extends base interfaces [vendor/php/php-src/tests/classes/interface_doubled.phpt]
ZE2 An interface is inherited [vendor/php/php-src/tests/classes/interface_implemented.phpt]
ZE2 An interface cannot be instantiated [vendor/php/php-src/tests/classes/interface_instantiate.phpt]
ZE2 An interface cannot have properties [vendor/php/php-src/tests/classes/interface_member.phpt]
ZE2 An interface method must be abstract [vendor/php/php-src/tests/classes/interface_method.phpt]
ZE2 An interface method cannot be final [vendor/php/php-src/tests/classes/interface_method_final.phpt]
ZE2 An interface method cannot be private [vendor/php/php-src/tests/classes/interface_method_private.phpt]
ZE2 An interface must be implemented [vendor/php/php-src/tests/classes/interface_must_be_implemented.phpt]
ZE2 An interface method allows additional default arguments [vendor/php/php-src/tests/classes/interface_optional_arg.phpt]
default argument value in interface implementation [vendor/php/php-src/tests/classes/interface_optional_arg_002.phpt]
default argument value in and in implementing class with interface in included file [vendor/php/php-src/tests/classes/interface_optional_arg_003.phpt]
ZE2 interfaces [vendor/php/php-src/tests/classes/interfaces_001.phpt]
ZE2 interface with an unimplemented method [vendor/php/php-src/tests/classes/interfaces_002.phpt]
ZE2 interface and __construct [vendor/php/php-src/tests/classes/interfaces_003.phpt]
ZE2 iterators and foreach [vendor/php/php-src/tests/classes/iterators_001.phpt]
ZE2 iterators and break [vendor/php/php-src/tests/classes/iterators_002.phpt]
ZE2 iterators and break [vendor/php/php-src/tests/classes/iterators_003.phpt]
ZE2 iterators must be implemented [vendor/php/php-src/tests/classes/iterators_004.phpt]
ZE2 iterators cannot implement Traversable alone [vendor/php/php-src/tests/classes/iterators_005.phpt]
ZE2 iterators and array wrapping [vendor/php/php-src/tests/classes/iterators_006.phpt]
ZE2 iterators and exceptions [vendor/php/php-src/tests/classes/iterators_007.phpt]
Ensure plain userspace superclass does not override special iterator behaviour on child class. [vendor/php/php-src/tests/classes/iterators_008.phpt]
In $a->$b[Y](), $b[Y] represents a method name on $a. But in $a->X[Y](), $a->X[Y] represents a global function name. [vendor/php/php-src/tests/classes/method_call_variation_001.phpt]
Method override allows optional default argument [vendor/php/php-src/tests/classes/method_override_optional_arg_001.phpt]
Omitting optional arg in method inherited from abstract class [vendor/php/php-src/tests/classes/method_override_optional_arg_002.phpt]
Confirm difference between assigning new directly and by reference. [vendor/php/php-src/tests/classes/new_001.phpt]
ZE2 A private method can only be called inside the class [vendor/php/php-src/tests/classes/private_001.phpt]
ZE2 A private method cannot be called in another class [vendor/php/php-src/tests/classes/private_002.phpt]
ZE2 A private method cannot be called in a derived class [vendor/php/php-src/tests/classes/private_003.phpt]
ZE2 A private method cannot be called in a derived class [vendor/php/php-src/tests/classes/private_003b.phpt]
ZE2 A private method cannot be called in a derived class [vendor/php/php-src/tests/classes/private_004.phpt]
ZE2 A private method cannot be called in a derived class [vendor/php/php-src/tests/classes/private_004b.phpt]
ZE2 A private method cannot be called in a derived class [vendor/php/php-src/tests/classes/private_005.phpt]
ZE2 A private method cannot be called in a derived class [vendor/php/php-src/tests/classes/private_005b.phpt]
ZE2 A private method can be overwritten in a second derived class [vendor/php/php-src/tests/classes/private_006.phpt]
ZE2 A private method can be overwritten in a second derived class [vendor/php/php-src/tests/classes/private_006b.phpt]
ZE2 A derived class does not know about privates of ancestors [vendor/php/php-src/tests/classes/private_007.phpt]
ZE2 A derived class does not know about privates of ancestors [vendor/php/php-src/tests/classes/private_007b.phpt]
ZE2 A private member is [vendor/php/php-src/tests/classes/private_members.phpt]
ZE2 A derived class does not know anything about inherited private methods [vendor/php/php-src/tests/classes/private_redeclare.phpt]
Redeclare inherited private static property as private. [vendor/php/php-src/tests/classes/property_override_privateStatic_private.phpt]
Redeclare inherited private static property as private static. [vendor/php/php-src/tests/classes/property_override_privateStatic_privateStatic.phpt]
Redeclare inherited private static property as protected. [vendor/php/php-src/tests/classes/property_override_privateStatic_protected.phpt]
Redeclare inherited private static property as protected static. [vendor/php/php-src/tests/classes/property_override_privateStatic_protectedStatic.phpt]
Redeclare inherited private static property as public. [vendor/php/php-src/tests/classes/property_override_privateStatic_public.phpt]
Redeclare inherited private static property as public static. [vendor/php/php-src/tests/classes/property_override_privateStatic_publicStatic.phpt]
Redeclare inherited private property as private. [vendor/php/php-src/tests/classes/property_override_private_private.phpt]
Redeclare inherited private property as private static. [vendor/php/php-src/tests/classes/property_override_private_privateStatic.phpt]
Redeclare inherited private property as protected. [vendor/php/php-src/tests/classes/property_override_private_protected.phpt]
Redeclare inherited private property as protected static. [vendor/php/php-src/tests/classes/property_override_private_protectedStatic.phpt]
Redeclare inherited private property as public. [vendor/php/php-src/tests/classes/property_override_private_public.phpt]
Redeclare inherited private property as public static. [vendor/php/php-src/tests/classes/property_override_private_publicStatic.phpt]
Redeclare inherited protected static property as private. [vendor/php/php-src/tests/classes/property_override_protectedStatic_private.phpt]
Redeclare inherited protected static property as private static. [vendor/php/php-src/tests/classes/property_override_protectedStatic_privateStatic.phpt]
Redeclare inherited protected static property as protected. [vendor/php/php-src/tests/classes/property_override_protectedStatic_protected.phpt]
Redeclare inherited protected static property as protected static. [vendor/php/php-src/tests/classes/property_override_protectedStatic_protectedStatic.phpt]
Redeclare inherited protected static property as public. [vendor/php/php-src/tests/classes/property_override_protectedStatic_public.phpt]
Redeclare inherited protected static property as public static. [vendor/php/php-src/tests/classes/property_override_protectedStatic_publicStatic.phpt]
Redeclare inherited protected property as private (duplicates Zend/tests/errmsg_023.phpt). [vendor/php/php-src/tests/classes/property_override_protected_private.phpt]
Redeclare inherited protected property as private static. [vendor/php/php-src/tests/classes/property_override_protected_privateStatic.phpt]
Redeclare inherited protected property as protected. [vendor/php/php-src/tests/classes/property_override_protected_protected.phpt]
Redeclare inherited protected property as protected static. [vendor/php/php-src/tests/classes/property_override_protected_protectedStatic.phpt]
Redeclare inherited protected property as public. [vendor/php/php-src/tests/classes/property_override_protected_public.phpt]
Redeclare inherited protected property as public static. [vendor/php/php-src/tests/classes/property_override_protected_publicStatic.phpt]
Redeclare inherited public static property as private. [vendor/php/php-src/tests/classes/property_override_publicStatic_private.phpt]
Redeclare inherited public static property as private static. [vendor/php/php-src/tests/classes/property_override_publicStatic_privateStatic.phpt]
Redeclare inherited public static property as protected. [vendor/php/php-src/tests/classes/property_override_publicStatic_protected.phpt]
Redeclare inherited public static property as protected static. [vendor/php/php-src/tests/classes/property_override_publicStatic_protectedStatic.phpt]
Redeclare inherited public static property as public. [vendor/php/php-src/tests/classes/property_override_publicStatic_public.phpt]
Redeclare inherited public static property as public static. [vendor/php/php-src/tests/classes/property_override_publicStatic_publicStatic.phpt]
Redeclare inherited public property as private. [vendor/php/php-src/tests/classes/property_override_public_private.phpt]
Redeclare inherited public property as private static. [vendor/php/php-src/tests/classes/property_override_public_privateStatic.phpt]
Redeclare inherited public property as protected. [vendor/php/php-src/tests/classes/property_override_public_protected.phpt]
Redeclare inherited public property as protected static. [vendor/php/php-src/tests/classes/property_override_public_protectedStatic.phpt]
Redeclare inherited public property as public. [vendor/php/php-src/tests/classes/property_override_public_public.phpt]
Redeclare inherited public property as public static. [vendor/php/php-src/tests/classes/property_override_public_publicStatic.phpt]
Unsetting and recreating private properties. [vendor/php/php-src/tests/classes/property_recreate_private.phpt]
Unsetting and recreating protected properties. [vendor/php/php-src/tests/classes/property_recreate_protected.phpt]
ZE2 A protected method can only be called inside the class [vendor/php/php-src/tests/classes/protected_001.phpt]
ZE2 A protected method can only be called inside the class [vendor/php/php-src/tests/classes/protected_001b.phpt]
ZE2 A protected method cannot be called in another class [vendor/php/php-src/tests/classes/protected_002.phpt]
ZE2 Serializable [vendor/php/php-src/tests/classes/serialize_001.phpt]
ZE2 singleton [vendor/php/php-src/tests/classes/singleton_001.phpt]
ZE2 You cannot overload a static method with a non static method [vendor/php/php-src/tests/classes/static_mix_1.phpt]
ZE2 You cannot overload a non static method with a static method [vendor/php/php-src/tests/classes/static_mix_2.phpt]
Attempting to access static properties using instance property syntax [vendor/php/php-src/tests/classes/static_properties_003.phpt]
Attempting to access static properties using instance property syntax [vendor/php/php-src/tests/classes/static_properties_003_error1.phpt]
Attempting to access static properties using instance property syntax [vendor/php/php-src/tests/classes/static_properties_003_error2.phpt]
Attempting to access static properties using instance property syntax [vendor/php/php-src/tests/classes/static_properties_003_error3.phpt]
Attempting to access static properties using instance property syntax [vendor/php/php-src/tests/classes/static_properties_003_error4.phpt]
Inherited static properties can be separated from their reference set. [vendor/php/php-src/tests/classes/static_properties_004.phpt]
Assigning to a non-existent static property [vendor/php/php-src/tests/classes/static_properties_undeclared_assign.phpt]
Assigning & incrementing a non-existent static property [vendor/php/php-src/tests/classes/static_properties_undeclared_assignInc.phpt]
Assigning a non-existent static property by reference [vendor/php/php-src/tests/classes/static_properties_undeclared_assignRef.phpt]
Incrementing a non-existent static property [vendor/php/php-src/tests/classes/static_properties_undeclared_inc.phpt]
Reading a non-existent static property [vendor/php/php-src/tests/classes/static_properties_undeclared_read.phpt]
ZE2 $this can be an argument to a static function [vendor/php/php-src/tests/classes/static_this.phpt]
ZE2 $this cannot be exchanged [vendor/php/php-src/tests/classes/this.phpt]
ZE2 __toString() [vendor/php/php-src/tests/classes/tostring_001.phpt]
ZE2 __toString() in __destruct [vendor/php/php-src/tests/classes/tostring_002.phpt]
ZE2 __toString() in __destruct/exception [vendor/php/php-src/tests/classes/tostring_003.phpt]
Object to string conversion: error cases and behaviour variations. [vendor/php/php-src/tests/classes/tostring_004.phpt]
ZE2 class type hinting [vendor/php/php-src/tests/classes/type_hinting_001.phpt]
ZE2 class type hinting non existing class [vendor/php/php-src/tests/classes/type_hinting_002.phpt]
ZE2 class type hinting with arrays [vendor/php/php-src/tests/classes/type_hinting_003.phpt]
Ensure type hints are enforced for functions invoked as callbacks. [vendor/php/php-src/tests/classes/type_hinting_004.phpt]
Check type hint compatibility in overrides with array hints. [vendor/php/php-src/tests/classes/type_hinting_005a.phpt]
Check type hint compatibility in overrides with array hints. [vendor/php/php-src/tests/classes/type_hinting_005b.phpt]
Check type hint compatibility in overrides with array hints. [vendor/php/php-src/tests/classes/type_hinting_005c.phpt]
Check type hint compatibility in overrides with array hints. [vendor/php/php-src/tests/classes/type_hinting_005d.phpt]
Un-setting instance properties causes magic methods to be called when trying to access them from outside the magic
methods themselves. [vendor/php/php-src/tests/classes/unset_properties.phpt]
ZE2 A redeclared method must have the same or higher visibility [vendor/php/php-src/tests/classes/visibility_000a.phpt]
ZE2 A redeclared method must have the same or higher visibility [vendor/php/php-src/tests/classes/visibility_000b.phpt]
ZE2 A redeclared method must have the same or higher visibility [vendor/php/php-src/tests/classes/visibility_001a.phpt]
ZE2 A redeclared method must have the same or higher visibility [vendor/php/php-src/tests/classes/visibility_001b.phpt]
ZE2 A redeclared method must have the same or higher visibility [vendor/php/php-src/tests/classes/visibility_002a.phpt]
ZE2 A redeclared method must have the same or higher visibility [vendor/php/php-src/tests/classes/visibility_002b.phpt]
ZE2 A redeclared method must have the same or higher visibility [vendor/php/php-src/tests/classes/visibility_003b.phpt]
ZE2 foreach and property visibility [vendor/php/php-src/tests/classes/visibility_005.phpt]
Testing register_shutdown_function() with timeout. (Bug: #21513) [vendor/php/php-src/tests/func/005a.phpt]
function with many parameters [vendor/php/php-src/tests/func/010.phpt]
$this in constructor test [vendor/php/php-src/tests/lang/030.phpt]
ZE2: set_exception_handler() [vendor/php/php-src/tests/lang/035.phpt]
Child public element should not override parent private element in parent methods [vendor/php/php-src/tests/lang/036.phpt]
'Static' binding for private variables [vendor/php/php-src/tests/lang/037.phpt]
Convert warnings to exceptions [vendor/php/php-src/tests/lang/038.phpt]
Catch Interfaces [vendor/php/php-src/tests/lang/039.phpt]
foreach into array [vendor/php/php-src/tests/lang/040.phpt]
Dynamic access of static members [vendor/php/php-src/tests/lang/041.phpt]
Dynamic access of constants [vendor/php/php-src/tests/lang/042.phpt]
Dynamic call for static methods [vendor/php/php-src/tests/lang/043.phpt]
Dynamic call for static methods dynamically named [vendor/php/php-src/tests/lang/044.phpt]
Bug #17115 (lambda functions produce segfault with static vars) [vendor/php/php-src/tests/lang/bug17115.phpt]
Bug #19943 (memleaks) [vendor/php/php-src/tests/lang/bug19943.phpt]
Bug #20175 (Static vars can't store ref to new instance) [vendor/php/php-src/tests/lang/bug20175.phpt]
Bug #21094 (set_error_handler not accepting methods) [vendor/php/php-src/tests/lang/bug21094.phpt]
Bug #21600 (assign by reference function call changes variable contents) [vendor/php/php-src/tests/lang/bug21600.phpt]
Bug #21669 ("$obj = new $this->var;" doesn't work) [vendor/php/php-src/tests/lang/bug21669.phpt]
Bug #21820 ("$arr['foo']" generates bogus E_NOTICE, should be E_PARSE) [vendor/php/php-src/tests/lang/bug21820.phpt]
Bug #21849 (self::constant doesn't work as method's default parameter) [vendor/php/php-src/tests/lang/bug21849.phpt]
Bug #21961 (get_parent_class() segfault) [vendor/php/php-src/tests/lang/bug21961.phpt]
Bug #22231 (segfault when returning a global variable by reference) [vendor/php/php-src/tests/lang/bug22231.phpt]
Bug #22510 (segfault among complex references) [vendor/php/php-src/tests/lang/bug22510.phpt]
Bug #22592 (cascading assignments to strings with curly braces broken) [vendor/php/php-src/tests/lang/bug22592.phpt]
Bug #22690 (ob_start() is broken with create_function() callbacks) [vendor/php/php-src/tests/lang/bug22690.phpt]
Bug #23279 (exception handler stops after first function call) [vendor/php/php-src/tests/lang/bug23279.phpt]
Bug #23384 (use of class constants in statics) [vendor/php/php-src/tests/lang/bug23384.phpt]
Bug #23489 (ob_start() is broken with method callbacks) [vendor/php/php-src/tests/lang/bug23489.phpt]
Bug #23584 (error line numbers off by one when using #!php) [vendor/php/php-src/tests/lang/bug23584.phpt]
Bug #23624 (foreach leaves current array key as null) [vendor/php/php-src/tests/lang/bug23624.phpt]
Bug #23922 (scope doesn't properly propagate into internal functions) [vendor/php/php-src/tests/lang/bug23922.phpt]
Bug #24396 (global $$variable broken) [vendor/php/php-src/tests/lang/bug24396.phpt]
Bug #24403 (scope doesn't properly propagate into internal functions) [vendor/php/php-src/tests/lang/bug24403.phpt]
Bug #24436 (isset() and empty() produce errors with non-existent variables in objects) [vendor/php/php-src/tests/lang/bug24436.phpt]
Bug #24499 (bogus handling of a public property as a private one) [vendor/php/php-src/tests/lang/bug24499.phpt]
Bug #24573 (debug_backtrace() crashes if $this is set to null) [vendor/php/php-src/tests/lang/bug24573.phpt]
Bug #24640 (var_export and var_dump can't output large float) [vendor/php/php-src/tests/lang/bug24640.phpt]
Bug #24658 (combo of typehint / reference causes crash) [vendor/php/php-src/tests/lang/bug24658.phpt]
Bug #24908 (super-globals can not be used in __destruct()) [vendor/php/php-src/tests/lang/bug24908.phpt]
Bug #24926 (lambda function (create_function()) cannot be stored in a class property) [vendor/php/php-src/tests/lang/bug24926.phpt]
Bug #25547 (error_handler and array index with function call) [vendor/php/php-src/tests/lang/bug25547.phpt]
Bug #25922 (SEGV in error_handler when context is destroyed) [vendor/php/php-src/tests/lang/bug25922.phpt]
Bug #26182 (Object properties created redundantly) [vendor/php/php-src/tests/lang/bug26182.phpt]
Bug #26866 (segfault when exception raised in __get) [vendor/php/php-src/tests/lang/bug26866.phpt]
Bug #26869 (constant as the key of static array) [vendor/php/php-src/tests/lang/bug26869.phpt]
Bug #27439 (foreach() with $this segfaults) [vendor/php/php-src/tests/lang/bug27439.phpt]
Bug #28213 (crash in debug_print_backtrace in static methods) [vendor/php/php-src/tests/lang/bug28213.phpt]
Bug #29566 (foreach/string handling strangeness) [vendor/php/php-src/tests/lang/bug29566.phpt]
Bug #29893 (segfault when using array as index) [vendor/php/php-src/tests/lang/bug29893.phpt]
Bug #30578 (Output buffers flushed before calling __desctruct functions) [vendor/php/php-src/tests/lang/bug30578.phpt]
Bug #32828 (Throwing exception in output_callback function with ob_start and ob_end_clean leads to segfault) [vendor/php/php-src/tests/lang/bug32828.phpt]
Bug #35176 (include()/require()/*_once() produce wrong error messages about main()) [vendor/php/php-src/tests/lang/bug35176.phpt]
Bug #43958 (class name added into the error message) [vendor/php/php-src/tests/lang/bug43958.phpt]
Bug #44827 (Class error when trying to access :: as constant) [vendor/php/php-src/tests/lang/bug44827.phpt]
Bug #45392 (ob_start()/ob_end_clean() and memory_limit) [vendor/php/php-src/tests/lang/bug45392.phpt]
Bug #55754 (Only variables should be passed by reference for ZEND_SEND_PREFER_REF params) [vendor/php/php-src/tests/lang/bug55754.phpt]
Bug #7515 (weird & invisible referencing of objects) [vendor/php/php-src/tests/lang/bug7515.phpt]
Catchable fatal error [2] [vendor/php/php-src/tests/lang/catchable_error_002.phpt]
Test object compare when object handler different [vendor/php/php-src/tests/lang/compare_objects_basic2.phpt]
Evaluation order during assignments. [vendor/php/php-src/tests/lang/engine_assignExecutionOrder_001.phpt]
Evaluation order during assignments. [vendor/php/php-src/tests/lang/engine_assignExecutionOrder_002.phpt]
Evaluation order during assignments. [vendor/php/php-src/tests/lang/engine_assignExecutionOrder_003.phpt]
Evaluation order during assignments. [vendor/php/php-src/tests/lang/engine_assignExecutionOrder_004.phpt]
Check key execution order with &new. [vendor/php/php-src/tests/lang/engine_assignExecutionOrder_007.phpt]
Ensure by value assignments leave temporaries on the stack, for all sorts of assignees. [vendor/php/php-src/tests/lang/engine_assignExecutionOrder_008.phpt]
Execution ordering with comparison operators. [vendor/php/php-src/tests/lang/engine_assignExecutionOrder_009.phpt]
ZE2 errors caught as exceptions [vendor/php/php-src/tests/lang/error_2_exception_001.phpt]
Execution order of variables [vendor/php/php-src/tests/lang/execution_order.phpt]
Foreach loop tests - basic loop with just value and key => value. [vendor/php/php-src/tests/lang/foreachLoop.001.phpt]
Foreach loop tests - modifying the array during the loop. [vendor/php/php-src/tests/lang/foreachLoop.002.phpt]
Foreach loop tests - error case: not an array. [vendor/php/php-src/tests/lang/foreachLoop.003.phpt]
Foreach loop tests - using an array element as the $value [vendor/php/php-src/tests/lang/foreachLoop.004.phpt]
Foreach loop tests - modifying the array during the loop: special case. Behaviour is good since php 5.2.2. [vendor/php/php-src/tests/lang/foreachLoop.005.phpt]
Foreach loop tests - error case: key is a reference. [vendor/php/php-src/tests/lang/foreachLoop.006.phpt]
Foreach loop tests - foreach operates on the original array if the array is referenced outside the loop. [vendor/php/php-src/tests/lang/foreachLoop.009.phpt]
Changing from an interable type to a non iterable type during the iteration [vendor/php/php-src/tests/lang/foreachLoop.011.phpt]
Directly modifying an unreferenced array when foreach'ing over it. [vendor/php/php-src/tests/lang/foreachLoop.012.phpt]
Directly modifying an unreferenced array when foreach'ing over it while using &$value syntax. [vendor/php/php-src/tests/lang/foreachLoop.013.phpt]
Directly modifying a REFERENCED array when foreach'ing over it. [vendor/php/php-src/tests/lang/foreachLoop.014.phpt]
Directly modifying a REFERENCED array when foreach'ing over it while using &$value syntax. [vendor/php/php-src/tests/lang/foreachLoop.015.phpt]
Ensure foreach splits the iterated entity from its cow reference set, for all sorts of iterated entities. [vendor/php/php-src/tests/lang/foreachLoop.016.phpt]
foreach with Iterator. [vendor/php/php-src/tests/lang/foreachLoopIterator.001.phpt]
foreach with iterator and &$value reference [vendor/php/php-src/tests/lang/foreachLoopIterator.002.phpt]
foreach with iteratorAggregate [vendor/php/php-src/tests/lang/foreachLoopIteratorAggregate.001.phpt]
IteratorAggregate::getIterator bad return type [vendor/php/php-src/tests/lang/foreachLoopIteratorAggregate.002.phpt]
foreach with nested iteratorAggregates [vendor/php/php-src/tests/lang/foreachLoopIteratorAggregate.003.phpt]
Duplicate of zend test tests/classes/iterators_002.phpt without expected output from destructor [vendor/php/php-src/tests/lang/foreachLoopIteratorAggregate.004.phpt]
Foreach loop on objects - basic loop with just value and key => value. [vendor/php/php-src/tests/lang/foreachLoopObjects.001.phpt]
Foreach loop tests - visibility. [vendor/php/php-src/tests/lang/foreachLoopObjects.002.phpt]
Foreach loop tests - modifying the object during the loop. [vendor/php/php-src/tests/lang/foreachLoopObjects.003.phpt]
Foreach loop tests - Removing the current element from an iterated object. [vendor/php/php-src/tests/lang/foreachLoopObjects.004.phpt]
Foreach loop tests - removing properties before and after the current property during the loop. [vendor/php/php-src/tests/lang/foreachLoopObjects.005.phpt]
Foreach loop tests - substituting the entire iterated entity during the loop. [vendor/php/php-src/tests/lang/foreachLoopObjects.006.phpt]
Including a file in the current script directory from an included function [vendor/php/php-src/tests/lang/include_variation2.phpt]
Including a file in the current script directory from eval'd code [vendor/php/php-src/tests/lang/include_variation3.phpt]
Test / operator : various numbers as strings [vendor/php/php-src/tests/lang/operators/divide_variationStr.phpt]
Test * operator : various numbers as strings [vendor/php/php-src/tests/lang/operators/multiply_variationStr.phpt]
passing of function parameters by reference [vendor/php/php-src/tests/lang/passByReference_001.phpt]
Attempt to pass a constant by reference [vendor/php/php-src/tests/lang/passByReference_002.phpt]
Implicit initialisation when passing by reference [vendor/php/php-src/tests/lang/passByReference_003.phpt]
passing the return value from a function by reference [vendor/php/php-src/tests/lang/passByReference_004.phpt]
Pass uninitialised variables by reference and by value to test implicit initialisation. [vendor/php/php-src/tests/lang/passByReference_005.phpt]
Pass uninitialised objects and arrays by reference to test implicit initialisation. [vendor/php/php-src/tests/lang/passByReference_006.phpt]
Pass function and method calls by reference and by value. [vendor/php/php-src/tests/lang/passByReference_007.phpt]
Assignement as argument [vendor/php/php-src/tests/lang/passByReference_009.phpt]
Passing assignments by reference [vendor/php/php-src/tests/lang/passByReference_010.phpt]
Test pass by reference semantics [vendor/php/php-src/tests/lang/passByReference_012.phpt]
Returning a reference from a function. [vendor/php/php-src/tests/lang/returnByReference.002.phpt]
Returning a reference from a function [vendor/php/php-src/tests/lang/returnByReference.003.phpt]
Returning a reference from a static method [vendor/php/php-src/tests/lang/returnByReference.004.phpt]
Returning a reference from a method [vendor/php/php-src/tests/lang/returnByReference.005.phpt]
Returning a reference from a function via another function [vendor/php/php-src/tests/lang/returnByReference.006.phpt]
Returning a reference from a static method via another static method [vendor/php/php-src/tests/lang/returnByReference.007.phpt]
Returning a reference from a non-static method via another non-static method [vendor/php/php-src/tests/lang/returnByReference.008.phpt]
Returning a references returned by another function [vendor/php/php-src/tests/lang/returnByReference.009.phpt]
short_open_tag: Off [vendor/php/php-src/tests/lang/short_tags.002.phpt]
short_open_tag: On, asp_tags: On [vendor/php/php-src/tests/lang/short_tags.003.phpt]
short_open_tag: Off, asp_tags: Off [vendor/php/php-src/tests/lang/short_tags.004.phpt]
Statics in nested functions & evals. [vendor/php/php-src/tests/lang/static_variation_001.phpt]
Catching an exception thrown from an included file [vendor/php/php-src/tests/lang/throw_variation_001.phpt]
Bug #46897: ob_flush() should fail to flush unerasable buffers [vendor/php/php-src/tests/output/bug46897.phpt]
Bug #60321 (ob_get_status(true) no longer returns an array when buffer is empty) [vendor/php/php-src/tests/output/bug60321.phpt]
Bug #60768 Output buffer not discarded [vendor/php/php-src/tests/output/bug60768.phpt]
output buffering - fatalism [vendor/php/php-src/tests/output/ob_010.phpt]
output buffering - handlers/status [vendor/php/php-src/tests/output/ob_013.phpt]
output buffering - failure [vendor/php/php-src/tests/output/ob_014.phpt]
output buffering - failure [vendor/php/php-src/tests/output/ob_015.phpt]
output buffering - stati [vendor/php/php-src/tests/output/ob_017.phpt]
Test ob_clean() function : basic functionality [vendor/php/php-src/tests/output/ob_clean_basic_001.phpt]
Test return type and value, as well as basic behaviour, for ob_end_clean() [vendor/php/php-src/tests/output/ob_end_clean_basic_001.phpt]
Test ob_end_flush() function : basic functionality [vendor/php/php-src/tests/output/ob_end_flush_basic_001.phpt]
Test ob_flush() function : basic functionality [vendor/php/php-src/tests/output/ob_flush_basic_001.phpt]
Test ob_get_level() function : basic functionality [vendor/php/php-src/tests/output/ob_get_level_basic_001.phpt]
ob_get_status() function basic test [vendor/php/php-src/tests/output/ob_get_status.phpt]
Test ob_implicit_flush() function : wrong number of arguments [vendor/php/php-src/tests/output/ob_implicit_flush_error_001.phpt]
Test ob_implicit_flush() function : usage variation [vendor/php/php-src/tests/output/ob_implicit_flush_variation_001.phpt]
Test return type and value for ob_start() [vendor/php/php-src/tests/output/ob_start_basic_001.phpt]
ob_start(): Check behaviour with various callback return values. [vendor/php/php-src/tests/output/ob_start_basic_002.phpt]
ob_start(): ensure even fatal error test is affected by output buffering. [vendor/php/php-src/tests/output/ob_start_basic_003.phpt]
ob_start() chunk_size: confirm buffer is flushed after any output call that causes its length to equal or exceed chunk_size. [vendor/php/php-src/tests/output/ob_start_basic_004.phpt]
ob_start(): non-static method as static callbacks. [vendor/php/php-src/tests/output/ob_start_basic_005.phpt]
ob_start(): ensure multiple buffer initialization with a single call using arrays is not supported on PHP6 (http://bugs.php.net/42641) [vendor/php/php-src/tests/output/ob_start_basic_006.phpt]
ob_start(): Ensure unerasable buffer cannot be erased by ob_clean(), ob_end_clean() or ob_end_flush(). [vendor/php/php-src/tests/output/ob_start_basic_unerasable_002.phpt]
ob_start(): Ensure unerasable buffer cannot be accessed or erased by ob_get_clean(). [vendor/php/php-src/tests/output/ob_start_basic_unerasable_003.phpt]
ob_start(): Ensure unerasable buffer cannot be accessed or flushed by ob_get_flush(). [vendor/php/php-src/tests/output/ob_start_basic_unerasable_004.phpt]
ob_start(): Ensure unerasable buffer cannot be flushed by ob_flush() [vendor/php/php-src/tests/output/ob_start_basic_unerasable_005.phpt]
Test ob_start() with callbacks in variables [vendor/php/php-src/tests/output/ob_start_callbacks.phpt]
Test wrong number of arguments and wrong arg types for ob_start() [vendor/php/php-src/tests/output/ob_start_error_001.phpt]
Test wrong number of arguments and wrong arg types for ob_start() [vendor/php/php-src/tests/output/ob_start_error_002.phpt]
Test ob_start() with object supplied but no method. [vendor/php/php-src/tests/output/ob_start_error_003.phpt]
Test ob_start() with non existent callback method. [vendor/php/php-src/tests/output/ob_start_error_004.phpt]
INI section allows '=' [vendor/php/php-src/tests/run-test/test004.phpt]
Error messages are shown [vendor/php/php-src/tests/run-test/test006.phpt]
Error message handling (without ZendOptimizer) [vendor/php/php-src/tests/run-test/test008a.phpt]
print_r(Object) [vendor/php/php-src/tests/run-test/test009.phpt]
Bug #53226 (file_exists fails on big filenames) [vendor/php/php-src/tests/security/bug53226.phpt]
openbase_dir runtime tightning [vendor/php/php-src/tests/security/open_basedir_001.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_chdir.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_chmod.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_copy.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_copy_variation1.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_dir.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_disk_free_space.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_error_log.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_error_log_variation.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_file.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_file_exists.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_file_get_contents.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_file_put_contents.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_fileatime.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_filectime.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_filegroup.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_fileinode.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_filemtime.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_fileowner.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_fileperms.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_filesize.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_filetype.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_fopen.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_glob.phpt]
Test open_basedir configuration for glob [vendor/php/php-src/tests/security/open_basedir_glob_variation.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_is_dir.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_is_executable.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_is_file.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_is_link.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_is_readable.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_is_writable.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_link.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_lstat.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_opendir.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_readlink.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_rename.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_rmdir.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_scandir.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_stat.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_symlink.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_tempnam.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_touch.phpt]
Test open_basedir configuration [vendor/php/php-src/tests/security/open_basedir_unlink.phpt]
Formatted print functions [vendor/php/php-src/tests/strings/002.phpt]
Bug #22592 (Cascading assignments to strings with curly braces broken) [vendor/php/php-src/tests/strings/bug22592.phpt]
testing the behavior of string offset chaining [vendor/php/php-src/tests/strings/offsets_chaining_3.phpt]
testing the behavior of string offset chaining [vendor/php/php-src/tests/strings/offsets_chaining_4.phpt]
testing the behavior of string offset chaining [vendor/php/php-src/tests/strings/offsets_chaining_5.phpt]
testing the behavior of string offsets [vendor/php/php-src/tests/strings/offsets_general.phpt]
=====================================================================

=====================================================================
WARNED TEST SUMMARY
---------------------------------------------------------------------
Bug #20539 (PHP CLI Segmentation Fault) [vendor/php/php-src/tests/basic/bug20539.phpt] (warn: ing: unlink(/Users/anthony/Dropbox/WorkNetbeans/PHP-PHP/vendor/php/php-src/tests/basic/sess_): No such file or directory in /Users/anthony/Dropbox/WorkNetbeans/PHP-PHP/lib/PHPPHP/Engine/FunctionData/InternalProxy.php on line 19)
=====================================================================
</pre>