<?php

/*
 * @author Niklas von Hertzen <niklas at hertzen.com>
 * @created 9.7.2012 
 * @website http://hertzen.com
 */

class stdClass {
    
}

?>