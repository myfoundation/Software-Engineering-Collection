<?php

class ReflectionException extends Exception {
    
}
?>