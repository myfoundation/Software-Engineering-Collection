<?php

class ArrayObject implements IteratorAggregate, Traversable, ArrayAccess, Serializable, Countable {

    const STD_PROP_LIST = 1;
    const ARRAY_AS_PROPS = 2;
    
    private $pointer = 0;
    
    

}

?>