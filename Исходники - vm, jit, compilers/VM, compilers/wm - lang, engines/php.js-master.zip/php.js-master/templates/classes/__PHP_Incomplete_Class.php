<?php

class __PHP_Incomplete_Class {
    
    public $__PHP_Incomplete_Class_Name;
    
    public function __construct( $name ) {
        $this->__PHP_Incomplete_Class_Name = $name;
    }
    
}
?>