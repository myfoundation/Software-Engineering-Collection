<?php

interface Countable {
    /* Methods */

    abstract public function count();

}

?>