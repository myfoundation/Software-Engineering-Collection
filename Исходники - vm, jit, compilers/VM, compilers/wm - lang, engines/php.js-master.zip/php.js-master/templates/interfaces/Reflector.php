<?php

interface Reflector {
    /* Methods */
    abstract public static function export ();
    abstract public function  __toString ();
    
}
?>