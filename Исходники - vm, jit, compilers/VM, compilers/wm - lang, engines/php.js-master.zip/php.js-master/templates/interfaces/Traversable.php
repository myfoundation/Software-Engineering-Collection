<?php

interface Traversable {
    
}

?>