/* 
* @author Niklas von Hertzen <niklas at hertzen.com>
* @created 17.7.2012 
* @website http://hertzen.com
 */

PHP.Locales = {
  
    de_DE: {
        decimal_point: ",",
        thousands_sep: "."
    }  
    
    
};
