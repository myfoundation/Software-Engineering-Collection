/* 
* @author Niklas von Hertzen <niklas at hertzen.com>
* @created 30.6.2012 
* @website http://hertzen.com
 */


PHP.Modules.prototype.fclose = function( fp ) {

    return new PHP.VM.Variable( true );
};