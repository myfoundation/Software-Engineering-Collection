/* Automatically built from PHP version: 5.4.0-ZS5.6.0 */
PHP.Constants.UPLOAD_ERR_OK = 0;
PHP.Constants.UPLOAD_ERR_INI_SIZE = 1;
PHP.Constants.UPLOAD_ERR_FORM_SIZE = 2;
PHP.Constants.UPLOAD_ERR_PARTIAL = 3;
PHP.Constants.UPLOAD_ERR_NO_FILE = 4;
PHP.Constants.UPLOAD_ERR_NO_TMP_DIR = 6;
PHP.Constants.UPLOAD_ERR_CANT_WRITE = 7;
PHP.Constants.UPLOAD_ERR_EXTENSION = 8;
