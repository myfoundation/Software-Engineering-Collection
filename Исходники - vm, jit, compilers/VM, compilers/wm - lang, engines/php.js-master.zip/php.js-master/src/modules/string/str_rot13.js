/* 
* @author Niklas von Hertzen <niklas at hertzen.com>
* @created 10.7.2012 
* @website http://hertzen.com
 */

PHP.Modules.prototype.str_rot13 = function( str, arr ) {
    
    var FUNCTION_NAME = "str_rot13";
        
    if ( !this[ PHP.Compiler.prototype.SIGNATURE ]( arguments, FUNCTION_NAME, 1, [ ] ) ) {
        return new PHP.VM.Variable( null );
    }
 
    
    
    
};
  