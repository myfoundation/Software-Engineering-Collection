/* Automatically built from PHP version: 5.4.0-ZS5.6.0 */
PHP.Constants.E_ERROR = 1;
PHP.Constants.E_RECOVERABLE_ERROR = 4096;
PHP.Constants.E_WARNING = 2;
PHP.Constants.E_PARSE = 4;
PHP.Constants.E_NOTICE = 8;
PHP.Constants.E_STRICT = 2048;
PHP.Constants.E_DEPRECATED = 8192;
PHP.Constants.E_CORE_ERROR = 16;
PHP.Constants.E_CORE_WARNING = 32;
PHP.Constants.E_COMPILE_ERROR = 64;
PHP.Constants.E_COMPILE_WARNING = 128;
PHP.Constants.E_USER_ERROR = 256;
PHP.Constants.E_USER_WARNING = 512;
PHP.Constants.E_USER_NOTICE = 1024;
PHP.Constants.E_USER_DEPRECATED = 16384;
PHP.Constants.E_ALL = 32767;
