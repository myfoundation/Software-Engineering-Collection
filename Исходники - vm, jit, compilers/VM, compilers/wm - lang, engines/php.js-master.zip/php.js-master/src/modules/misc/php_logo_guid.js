/* 
* @author Niklas von Hertzen <niklas at hertzen.com>
* @created 9.7.2012 
* @website http://hertzen.com
 */


PHP.Modules.prototype.php_logo_guid = function(  ) {
    
    return new PHP.VM.Variable("PHPE9568F34-D428-11d2-A769-00AA001ACF42");
};