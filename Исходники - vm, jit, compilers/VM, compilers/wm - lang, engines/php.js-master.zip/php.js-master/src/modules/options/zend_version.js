/* 
* @author Niklas von Hertzen <niklas at hertzen.com>
* @created 20.7.2012 
* @website http://hertzen.com
 */



PHP.Modules.prototype.zend_version = function(  ) {
    
    return new PHP.VM.Variable("1.0.0");
};