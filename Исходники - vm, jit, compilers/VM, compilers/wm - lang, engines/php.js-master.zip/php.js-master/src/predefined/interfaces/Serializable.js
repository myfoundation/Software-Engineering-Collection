/* automatically built from Serializable.php*/
PHP.VM.Class.Predefined.Serializable = function( ENV, $$ ) {
ENV.$Class.INew( "Serializable", [], function( M, $, $$ ){
 M.Method( "serialize", 17, [], false, function( $, ctx, $Static ) {
})
.Method( "unserialize", 17, [{name:"serialized"}], false, function( $, ctx, $Static ) {
})
.Create()});

ENV.$Class.Get( "DateTime").prototype.Native = true;
};