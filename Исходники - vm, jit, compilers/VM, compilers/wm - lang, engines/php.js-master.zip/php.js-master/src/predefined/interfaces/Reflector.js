/* automatically built from Reflector.php*/
PHP.VM.Class.Predefined.Reflector = function( ENV, $$ ) {
ENV.$Class.INew( "Reflector", [], function( M, $, $$ ){
 M.Method( "export", 25, [], false, function( $, ctx, $Static ) {
})
.Method( "__toString", 17, [], false, function( $, ctx, $Static ) {
})
.Create()});

ENV.$Class.Get( "DateTime").prototype.Native = true;
};