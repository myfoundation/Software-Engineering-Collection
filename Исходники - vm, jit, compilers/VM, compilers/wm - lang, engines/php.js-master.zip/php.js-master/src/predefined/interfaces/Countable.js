/* automatically built from Countable.php*/
PHP.VM.Class.Predefined.Countable = function( ENV, $$ ) {
ENV.$Class.INew( "Countable", [], function( M, $, $$ ){
 M.Method( "count", 17, [], false, function( $, ctx, $Static ) {
})
.Create()});

ENV.$Class.Get( "DateTime").prototype.Native = true;
};