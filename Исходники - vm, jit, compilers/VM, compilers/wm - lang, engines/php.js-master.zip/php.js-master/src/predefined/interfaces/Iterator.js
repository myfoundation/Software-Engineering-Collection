/* automatically built from Iterator.php*/
PHP.VM.Class.Predefined.Iterator = function( ENV, $$ ) {
ENV.$Class.INew( "Iterator", ["Traversable"], function( M, $, $$ ){
 M.Method( "current", 1, [], false, function( $, ctx, $Static ) {
})
.Method( "key", 1, [], false, function( $, ctx, $Static ) {
})
.Method( "next", 1, [], false, function( $, ctx, $Static ) {
})
.Method( "rewind", 1, [], false, function( $, ctx, $Static ) {
})
.Method( "valid", 1, [], false, function( $, ctx, $Static ) {
})
.Create()});

ENV.$Class.Get( "DateTime").prototype.Native = true;
};