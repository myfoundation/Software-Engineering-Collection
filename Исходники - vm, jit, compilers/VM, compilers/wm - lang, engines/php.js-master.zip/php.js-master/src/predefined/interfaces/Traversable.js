/* automatically built from Traversable.php*/
PHP.VM.Class.Predefined.Traversable = function( ENV, $$ ) {
ENV.$Class.INew( "Traversable", [], function( M, $, $$ ){
 M.Create()});

ENV.$Class.Get( "DateTime").prototype.Native = true;
};