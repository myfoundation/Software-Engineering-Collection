/* automatically built from IteratorAggregate.php*/
PHP.VM.Class.Predefined.IteratorAggregate = function( ENV, $$ ) {
ENV.$Class.INew( "IteratorAggregate", ["Traversable"], function( M, $, $$ ){
 M.Method( "getIterator", 17, [], false, function( $, ctx, $Static ) {
})
.Create()});

ENV.$Class.Get( "DateTime").prototype.Native = true;
};