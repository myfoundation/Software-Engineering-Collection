/* automatically built from __PHP_Incomplete_Class.php*/
PHP.VM.Class.Predefined.__PHP_Incomplete_Class = function( ENV, $$ ) {
ENV.$Class.New( "__PHP_Incomplete_Class", 0, {}, function( M, $, $$ ){
 M.Variable( "__PHP_Incomplete_Class_Name", 1 )
.Method( "__construct", 1, [{name:"name"}], false, function( $, ctx, $Static ) {
$("this").$Prop( ctx, "__PHP_Incomplete_Class_Name" )._($("name"));
})
.Create()});

ENV.$Class.Get( "DateTime").prototype.Native = true;
};