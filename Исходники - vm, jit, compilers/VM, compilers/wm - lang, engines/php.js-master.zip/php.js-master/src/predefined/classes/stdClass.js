/* automatically built from stdClass.php*/
PHP.VM.Class.Predefined.stdClass = function( ENV, $$ ) {
ENV.$Class.New( "stdClass", 0, {}, function( M, $, $$ ){
 M.Create()});

ENV.$Class.Get( "DateTime").prototype.Native = true;
};