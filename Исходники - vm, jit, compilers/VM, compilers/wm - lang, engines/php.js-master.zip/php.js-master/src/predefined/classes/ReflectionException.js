/* automatically built from ReflectionException.php*/
PHP.VM.Class.Predefined.ReflectionException = function( ENV, $$ ) {
ENV.$Class.New( "ReflectionException", 0, {Extends: "Exception"}, function( M, $, $$ ){
 M.Create()});

ENV.$Class.Get( "DateTime").prototype.Native = true;
};