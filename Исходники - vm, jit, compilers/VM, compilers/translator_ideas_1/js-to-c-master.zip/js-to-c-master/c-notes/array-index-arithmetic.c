#include <stdio.h>

void* ptrArray[7];



int main() {
}
