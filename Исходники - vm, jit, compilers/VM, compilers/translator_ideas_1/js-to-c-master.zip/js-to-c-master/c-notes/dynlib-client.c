#include "dynlib.h"

int main() {
    hi();
}
