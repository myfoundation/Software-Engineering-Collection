void hi(void);
