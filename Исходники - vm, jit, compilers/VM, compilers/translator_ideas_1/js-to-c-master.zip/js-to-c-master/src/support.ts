/**
 * Code here is compiler support code, that needs to reference
 * interned values.
 */

