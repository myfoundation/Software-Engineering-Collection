// note - this is a header for the compiled
// output of prelude.js

void preludeLibraryInit(void);
