

void itCanAllocateAJsString() {
}
