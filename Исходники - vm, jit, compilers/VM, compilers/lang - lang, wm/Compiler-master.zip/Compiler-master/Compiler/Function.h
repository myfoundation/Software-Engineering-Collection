#pragma once

#include <string>

class Function {
public:

private:
	std::string name;
	int type;
};
