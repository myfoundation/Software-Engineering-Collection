#pragma once

#include <string>

class Variable {
	std::string name;
	int type;
};