#include "stdafx.h"

#include "Program.h"

void Program::addFunction() {

}

void Program::addGlobal() {
	
}