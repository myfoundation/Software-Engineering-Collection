#pragma once

#include "StatementTree.h"
#include "StatementListTree.h"
#include "ExprStatementTree.h"
#include "WhileStatementTree.h"
#include "ForStatementTree.h"
#include "DeclStatementTree.h"
#include "IfStatementTree.h"
#include "ReturnStatementTree.h"
#include "DeclArrayStmtTree.h"
#include "DeleteStmt.h"