#ifndef LISTING_H
#define LISTING_H

#include "vMachine.h"

void showListing(VM* vm);

#endif