#ifndef RUNLOOP_H
#define RUNLOOP_H

#include "vMachine.h"

int runLoop(VM* vm);

#endif