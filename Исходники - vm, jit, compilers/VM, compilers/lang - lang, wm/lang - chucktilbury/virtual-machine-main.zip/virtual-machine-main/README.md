https://github.com/chucktilbury/virtual-machine

# virtual-machine
Simple virtual machine and assembler
