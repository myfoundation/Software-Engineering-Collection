# This runs in approximately 1 second with Python3.
def fib(n):
    if n < 2:
        return n
    else:
        return fib(n-1) + fib(n-2)

print("the 35th number in the fibonacci series is ", fib(35))
