# Assembler
This is the goldfish assembler. It is a stand-alone program that accepts the output of the compiler and converts it to the binary format that the virtual machine can use.

```

use: gfas <parameters> <file(s)>
This is the assembler. It reads the assembly language input
and converts it to a binary for use by the virtual machine.

-o <str> output file name
-v <num> verbosity number from 0 to 10
-h ----- show the help information

```
