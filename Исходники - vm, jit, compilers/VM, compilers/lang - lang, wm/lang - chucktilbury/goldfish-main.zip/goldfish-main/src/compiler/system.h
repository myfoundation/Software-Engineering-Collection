#ifndef _COMPILER_SYSTEM_H
#define _COMPILER_SYSTEM_H

#include <ctype.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#endif /* _COMPILER_SYSTEM_H */
