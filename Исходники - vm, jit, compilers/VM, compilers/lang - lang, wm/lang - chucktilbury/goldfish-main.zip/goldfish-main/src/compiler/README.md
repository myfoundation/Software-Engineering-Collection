# Compiler
This is the goldfish compiler. It accepts source code written in the goldfish language and converts it to assembly that is compatible with the assembler for the virtual machine that is implemented with this project.
