#ifndef _COMPILER_GOLDFISH_H
#define _COMPILER_GOLDFISH_H

#include "system.h"

#include "errors.h"
#include "memory.h"

#endif /* _COMPILER_GOLDFISH_H */
