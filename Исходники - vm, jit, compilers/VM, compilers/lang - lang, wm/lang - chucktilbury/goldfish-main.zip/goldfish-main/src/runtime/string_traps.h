#ifndef _RUNTIME_STRING_TRAPS_H
#define _RUNTIME_STRING_TRAPS_H

bool format_str_trap();

#endif /* _RUNTIME_STRING_TRAPS_H */
