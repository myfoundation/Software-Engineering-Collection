#ifndef _RUNTIME_TIME_TRAPS_H
#define _RUNTIME_TIME_TRAPS_H

bool get_time_trap();
bool show_time_trap();
bool get_clock_trap();
bool dif_clock_trap();

#endif /* _RUNTIME_TIME_TRAPS_H */
