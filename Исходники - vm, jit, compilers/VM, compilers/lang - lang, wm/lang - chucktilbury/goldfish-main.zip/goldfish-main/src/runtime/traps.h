#ifndef _RUNTIME_TRAPS_H
#define _RUNTIME_TRAPS_H

#include "abort_traps.h"
#include "print_traps.h"
#include "string_traps.h"
#include "time_traps.h"

#endif /* _RUNTIME_TRAPS_H */
