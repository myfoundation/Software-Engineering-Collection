#ifndef _RUNTIME_RUNTIME_H
#define _RUNTIME_RUNTIME_H

#include <stdbool.h>
#include <stdint.h>

bool handleTrap(uint16_t tno);

#endif /* _RUNTIME_RUNTIME_H */
