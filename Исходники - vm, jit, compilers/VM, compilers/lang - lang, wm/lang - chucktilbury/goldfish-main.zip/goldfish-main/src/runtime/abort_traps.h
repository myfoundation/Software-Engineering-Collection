#ifndef _RUNTIME_ABORT_TRAPS_H
#define _RUNTIME_ABORT_TRAPS_H

bool abort_trap();

#endif /* _RUNTIME_ABORT_TRAPS_H */
