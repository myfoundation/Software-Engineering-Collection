#ifndef _RUNTIME_PRINT_TRAPS_H
#define _RUNTIME_PRINT_TRAPS_H

bool print_trap();
bool dbg_print_trap();


#endif /* _RUNTIME_PRINT_TRAPS_H */
