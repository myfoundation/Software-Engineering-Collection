# Runtime
These are routines that are written in C but are accessed at runtime in Goldfish source code.
