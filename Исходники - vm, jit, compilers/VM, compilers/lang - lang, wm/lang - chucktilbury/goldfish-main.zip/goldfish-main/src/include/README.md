# Include files
The files in this directory are part of this project. Files in subdirectories are part of external projects that are named after the project.

#### gc
This is the garbage collection library.
Documentation is here: https://www.hboehm.info/gc/

