#ifndef _VMACHINE_RUNLOOP_H
#define _VMACHINE_RUNLOOP_H

typedef bool (*runloopHandler)();

void runloop();

#endif /* _VMACHINE_RUNLOOP_H */
