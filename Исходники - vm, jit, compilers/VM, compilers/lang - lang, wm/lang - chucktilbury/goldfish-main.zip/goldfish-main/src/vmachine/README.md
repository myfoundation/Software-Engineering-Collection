# Vmachine
This is the stand-alone virtual machine. It accepts binary files that were created by the Goldfish compiler and/or by the assembler.

```
use: vmachine <parameters> <file(s)>
This is the virtual machine. It reads a binary
file that was created with the assembler and
runs it.

-t ----- enable trace output
-v <num> verbosity number from 0 to 10
-h ----- print help information

```
