#ifndef ASM_ERROR_H
#define ASM_ERROR_H

void syntaxError(const char* fmt, ...);
void genericError(const char* fmt, ...);

#endif