#ifndef FILE_IO_H
#define FILE_IO_H

void loadVM(const char* fname);
void saveVM(const char* fname);

#endif