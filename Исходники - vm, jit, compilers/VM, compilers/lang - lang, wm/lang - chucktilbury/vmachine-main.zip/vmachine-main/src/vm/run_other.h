#ifndef RUN_OTHER_H
#define RUN_OTHER_H

int do_OP_NOOP();
int do_OP_EXIT();
int do_OP_PRINT();
int do_OP_PRINTS();
int do_OP_EXCEPT();
int do_OP_SAVE();
int do_OP_ERROR();
int do_OP_TRAP();
int do_OP_CAST();
int do_OP_LOCAL();

#endif