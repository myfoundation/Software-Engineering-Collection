#ifndef RUN_PUSH_H
#define RUN_PUSH_H

int do_OP_PUSH();
int do_OP_PUSH8();
int do_OP_PUSH16();
int do_OP_PUSH32();
int do_OP_POP();
int do_OP_PEEK();

#endif