#ifndef RUN_COMP_H
#define RUN_COMP_H

int do_OP_NOT();
int do_OP_EQ();
int do_OP_NEQ();
int do_OP_LEQ();
int do_OP_GEQ();
int do_OP_LESS();
int do_OP_GTR();


#endif