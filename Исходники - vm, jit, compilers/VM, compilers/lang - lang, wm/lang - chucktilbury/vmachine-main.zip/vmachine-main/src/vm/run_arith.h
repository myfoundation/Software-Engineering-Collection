#ifndef RUN_ARITH_H
#define RUN_ARITH_H

int do_OP_ADD();
int do_OP_SUB();
int do_OP_MUL();
int do_OP_DIV();
int do_OP_MOD();
int do_OP_NEG();

#endif