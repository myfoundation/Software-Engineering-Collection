#ifndef RUN_JMP_H
#define RUN_JMP_H

int do_OP_JMP();
int do_OP_JMPIF();
int do_OP_CALLX();
int do_OP_CALL();
int do_OP_RETURN();

#endif