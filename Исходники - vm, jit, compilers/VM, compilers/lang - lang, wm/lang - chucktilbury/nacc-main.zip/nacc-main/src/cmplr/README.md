# NINC/nincc
This is the compiler for NINC
