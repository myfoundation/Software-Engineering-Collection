# NINC/common
This directory holds code that is common to the other source code directories.
