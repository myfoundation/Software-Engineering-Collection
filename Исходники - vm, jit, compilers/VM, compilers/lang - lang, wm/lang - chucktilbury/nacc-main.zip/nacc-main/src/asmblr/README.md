# NINC/ninca
This is the assembler for NINC
