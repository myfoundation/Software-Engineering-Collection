
#include "common.h"
#include "vmach.h"

int main() {

    return 0;
}
