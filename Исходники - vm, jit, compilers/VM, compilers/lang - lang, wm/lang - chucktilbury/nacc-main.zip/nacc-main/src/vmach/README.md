# NINC/nincv
This is the virtual machine for NINC
