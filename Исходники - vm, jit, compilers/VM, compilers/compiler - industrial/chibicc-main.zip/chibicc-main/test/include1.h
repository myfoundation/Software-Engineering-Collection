#include "include2.h"

char *include1_filename = __FILE__;
int include1_line = __LINE__;

int include1 = 5;
