#define foo 3
