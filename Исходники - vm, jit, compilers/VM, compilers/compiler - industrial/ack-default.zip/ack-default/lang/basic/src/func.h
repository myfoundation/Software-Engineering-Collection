/*  Copyright (c) 2019 ACK Project.
 *  See the copyright notice in the ACK home directory,
 *  in the file "Copyright".
 *
 */
#ifndef __FUNC_H_INCLUDED__
#define __FUNC_H_INCLUDED__


extern int callfcn(int fcnnr,int cnt,int *typetable);


#endif /* __FUNC_H_INCLUDED__ */
