#define __NO_DEFS
#include <math.h>
#include "lib.h"

double _sin(double x) { return sin(x); }
double _cos(double x) { return cos(x); }
double _tan(double x) { return tan(x); }
