#include "lib.h"

long _abl(long i)
{
	return (i >= 0 ? i : -i);
}
double _abr(double f)
{
	return (f >= 0.0 ? f : -f);
}
