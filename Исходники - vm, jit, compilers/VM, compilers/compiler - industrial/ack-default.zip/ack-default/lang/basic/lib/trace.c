#include <stdio.h>
#include "lib.h"

void _trace(int i)
{
	printf("[%d]", i);
}
