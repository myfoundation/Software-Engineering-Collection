#include <math.h>
#include "lib.h"

double _power(double x, double y) { return pow(x, y); }
