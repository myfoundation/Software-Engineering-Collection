#include <math.h>
#include "lib.h"

double _atn(double x) { return atan(x); }
