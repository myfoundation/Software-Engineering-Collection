/*  Copyright (c) 2019 ACK Project.
 *  See the copyright notice in the ACK home directory, 
 *  in the file "Copyright".
 *
 *  Created on: 2019-02-07
 *  
 */
#ifndef PRAGMA_H_
#define PRAGMA_H_

void do_pragma(void);

#endif /* PRAGMA_H_ */
