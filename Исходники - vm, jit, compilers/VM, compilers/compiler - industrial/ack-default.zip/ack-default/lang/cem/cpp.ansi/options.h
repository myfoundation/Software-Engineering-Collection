/*  Copyright (c) 2019 ACK Project.
 *  See the copyright notice in the ACK home directory, 
 *  in the file "Copyright".
 *
 *  Created on: 2019-02-09
 *  
 */
#ifndef OPTIONS_H_
#define OPTIONS_H_

void do_option(char *text);

#endif /* OPTIONS_H_ */
