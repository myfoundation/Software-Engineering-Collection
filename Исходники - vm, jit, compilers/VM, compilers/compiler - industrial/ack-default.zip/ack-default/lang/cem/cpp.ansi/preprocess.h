/*  Copyright (c) 2019 ACK Project.
 *  See the copyright notice in the ACK home directory, 
 *  in the file "Copyright".
 *
 *  Created on: 2019-02-09
 *  
 */
#ifndef PREPROCESS_H_
#define PREPROCESS_H_

void do_pragma(void);
void preprocess(char *fn);

#endif /* PREPROCESS_H_ */
