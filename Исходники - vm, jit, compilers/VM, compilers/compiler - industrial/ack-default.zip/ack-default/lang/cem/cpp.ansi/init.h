/*  Copyright (c) 2019 ACK Project.
 *  See the copyright notice in the ACK home directory, 
 *  in the file "Copyright".
 *
 *  Created on: 2019-02-09
 *  
 */
#ifndef INIT_H_
#define INIT_H_

void init_pp(void);

#endif /* INIT_H_ */
