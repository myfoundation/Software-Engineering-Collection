/*
 * environ.c - define the variable environ
 */
/* $Id$ */

#include <unistd.h>

/* Contains storage for the environ variable. */

char** environ;
