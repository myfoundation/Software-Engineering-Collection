/* $Source$
 * $State$
 * $Revision$
 */

#ifndef _SYS_TIME_H
#define _SYS_TIME_H

#include <time.h>
#include <unistd.h>

#endif
