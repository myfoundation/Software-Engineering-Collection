/*
 * gets.c - read a line from a stream
 */
/* $Id$ */

#include <stdio.h>

char* gets(char* s)
{
	FILE* stream = stdin;
	int ch;
	char* ptr;

	ptr = s;
	while ((ch = getc(stream)) != EOF && ch != '\n')
		*ptr++ = ch;

	if (ch == EOF)
	{
		if (feof(stream))
		{
			if (ptr == s)
				return NULL;
		}
		else
			return NULL;
	}

	*ptr = '\0';
	return s;
}
