extern	double _atn();
double ARCTAN(statlink, x)
  int *statlink; double x;
  {return(_atn(x));}
