extern	double _cos();
double COS(statlink, x)
  int *statlink; double x;
  {return(_cos(x));}
