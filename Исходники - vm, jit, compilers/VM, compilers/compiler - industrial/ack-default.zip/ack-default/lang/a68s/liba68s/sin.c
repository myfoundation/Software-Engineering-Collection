extern	double _sin();
double SIN(statlink, x)
  int *statlink; double x;
  {return(_sin(x));}
