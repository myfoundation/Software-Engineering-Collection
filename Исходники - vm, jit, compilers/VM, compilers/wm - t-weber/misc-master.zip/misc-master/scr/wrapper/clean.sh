#!/bin/bash

rm -fv expr_parser_wrap.cxx
rm -fv expr_parser.py
rm -rfv __pycache__
rm -vf *.so
rm -fv SWIGTYPE_*

rm -vf *.class
rm -fv ExprParserD.java
rm -fv expr_parser.java
rm -fv expr_parserJNI.java
