#!/bin/sh

rm -f parser
rm -f parser_impl.cpp
rm -f parser_defs.h
rm -f stack.hh
rm -f lexer_impl.cpp
rm -f lexer_impl.h
rm -f parser.graph
rm -f parser.svg
rm -f parser.pdf
rm -f parser.report
rm -f parser.xml
