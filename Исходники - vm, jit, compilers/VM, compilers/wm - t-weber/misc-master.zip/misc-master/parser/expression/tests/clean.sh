#!/bin/sh

rm -f cyk
rm -f ll1
rm -f ll1_expr
rm -f ll1_lexer.cpp
rm -f lr1
rm -f lr1_expr
rm -f lr1_opprec
rm -f tmp.svg
rm -f tmp.graph
