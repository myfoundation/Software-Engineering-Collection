#!/bin/sh

rm -f parser
rm -f parser.tab.c
rm -f parser_impl.cpp
rm -f parser_defs.h
