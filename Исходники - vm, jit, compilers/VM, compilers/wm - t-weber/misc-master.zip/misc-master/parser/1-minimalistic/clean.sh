#!/bin/sh

rm -fv parser
rm -fv lexer_impl.cpp
rm -fv parser_impl.cpp
rm -fv parser_defs.h

rm -fv tst1.tab.c
rm -fv tst1.dot
rm -fv tst1.pdf
