#!/bin/sh

#make clean
rm -rf CMakeFiles
rm -rf charts_autogen
rm -f Makefile
rm -f CMakeCache.txt
rm -f cmake_install.cmake
rm -f charts
