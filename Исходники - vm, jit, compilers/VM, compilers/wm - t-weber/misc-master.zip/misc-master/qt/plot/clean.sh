#!/bin/sh

#make clean
rm -rf CMakeFiles
rm -rf qcp_autogen
rm -f Makefile
rm -f CMakeCache.txt
rm -f cmake_install.cmake
rm -f qcp
