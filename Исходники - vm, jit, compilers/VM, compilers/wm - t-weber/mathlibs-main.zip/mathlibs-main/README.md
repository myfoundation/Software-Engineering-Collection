# mathlibs
A collection of mathematical C++ template libraries (alpha version).

[![DOI: 10.5281/zenodo.5719810](https://zenodo.org/badge/DOI/10.5281/zenodo.5719810.svg)](https://doi.org/10.5281/zenodo.5719810)
