https://github.com/t-weber/lr1

# lr1
A small LR(1), LALR(1), SLR(1), and LL(1) parser generator. This parser generator mainly serves didactic purposes and is not optimised. An optimised version specialised on LALR(1) grammars is available here: https://github.com/t-weber/lalr1.

[![DOI: 10.5281/zenodo.3965097](https://zenodo.org/badge/DOI/10.5281/zenodo.3965097.svg)](https://doi.org/10.5281/zenodo.3965097)
