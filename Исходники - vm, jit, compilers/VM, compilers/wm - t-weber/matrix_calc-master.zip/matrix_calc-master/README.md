https://github.com/myfoundation/matrix_calc

# matrix_calc
A simple compiler for linear algebra calculations.

[![DOI: 10.5281/zenodo.3965097](https://zenodo.org/badge/DOI/10.5281/zenodo.3965097.svg)](https://doi.org/10.5281/zenodo.3965097)
