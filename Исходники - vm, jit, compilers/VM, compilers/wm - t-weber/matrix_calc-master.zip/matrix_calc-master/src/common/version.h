/**
 * version infos
 * @author Tobias Weber (orcid: 0000-0002-7230-1932)
 * @date 24-july-2022
 * @license: see 'LICENSE.GPL' file
 */

#ifndef __MCALC_VER_H__
#define __MCALC_VER_H__

#define MCALC_VER "0.4"

#endif
