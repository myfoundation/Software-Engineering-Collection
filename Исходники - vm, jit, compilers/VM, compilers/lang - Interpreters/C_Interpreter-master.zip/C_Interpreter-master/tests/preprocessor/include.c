#include "../tests/inc_test1.c"
a
/*
#ifndef FIB_NUM
#define FIB_NUM 5
#endif
*/


int main()
{
	int local = 54
	print local;
	func1();
	print a;
	func2(10, local /= 3, local - a*20);
	print local;

	local = fibbonaci(FIB_NUM);
	print local;

	return 0;
}
