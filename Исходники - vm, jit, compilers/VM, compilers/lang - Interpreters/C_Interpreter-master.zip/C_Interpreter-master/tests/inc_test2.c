
void func1(void)
{
	print a;
	int a = 2;
	print a;
	int local = 10 * a;
	print local;
}
