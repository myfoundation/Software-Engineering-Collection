#ifndef BASIC_TYPES
#define BASIC_TYPES

typedef unsigned char byte;


#endif

