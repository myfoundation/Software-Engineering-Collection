#pragma once

void dd_simplify_fname_c(char *s);
bool dd_fname_equal(const char *fn1, const char *fn2);
void dd_append_slash_c(char *fn);
char *dd_get_fname_location(char *buf, const char *filename);
