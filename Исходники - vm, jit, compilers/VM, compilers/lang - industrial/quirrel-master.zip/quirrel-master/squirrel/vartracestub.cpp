#include "vartrace.h"

void VarTrace::printStack(SQChar *, int) {}
