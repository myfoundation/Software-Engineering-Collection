.. Quirrel documentation master file, created by
   sphinx-quickstart on Sun Jan 31 00:26:52 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Quirrel documentation
=========================================

.. toctree::
   :maxdepth: 1

   introduction.rst
   diff_from_original.rst
   reference/index.rst
   stdlib/index.rst
   modules/index.rst
   modules/bindings.rst
   repl/index.rst
   rfcs/STATUS.md
   rfcs/README.md

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`


