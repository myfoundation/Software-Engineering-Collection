.. _limitation:


=================
Limitations
=================

.. index::
    single: Limitations

Quirrel has a number of limitations

 - Maximum number of local variables (including `let`-bindings) is **256**
 - Maximum nesting level of code tree is **500**