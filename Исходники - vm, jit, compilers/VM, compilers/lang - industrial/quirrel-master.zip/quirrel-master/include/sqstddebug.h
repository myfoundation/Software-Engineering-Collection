/*  see copyright notice in squirrel.h */
#ifndef _SQSTD_DEBUG_H_
#define _SQSTD_DEBUG_H_

#ifdef __cplusplus
extern "C" {
#endif

SQUIRREL_API SQRESULT sqstd_register_debuglib(HSQUIRRELVM v);


#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif // _SQSTD_DEBUG_H_
