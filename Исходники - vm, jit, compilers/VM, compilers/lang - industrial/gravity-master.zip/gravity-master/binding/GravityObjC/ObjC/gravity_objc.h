//
//  gravity_objc.h
//  GravityObjC
//
//  Created by Marco Bambini on 07/02/21.
//

#import <Foundation/Foundation.h>
#import "gravity_vm.h"

// dynamic bridge
void objc_register (gravity_vm *vm);
