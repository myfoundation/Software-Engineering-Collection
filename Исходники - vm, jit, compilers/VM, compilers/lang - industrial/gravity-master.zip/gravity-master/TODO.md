**FUNCTIONALITIES**
* Add support for modules
* Class extensions
* Code generation for ternary operator
* Code generation for switch statement
* Improve register allocation algorithm
* Improve parser error handling

**DOCUMENTATION AND EXAMPLES**
* Add examples with projects about API usage (C <-> Gravity)
* Add the objc bridge with documentation
