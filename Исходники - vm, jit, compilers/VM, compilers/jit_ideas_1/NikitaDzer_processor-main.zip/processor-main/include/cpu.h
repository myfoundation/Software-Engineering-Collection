//
// Created by User on 04.11.2021.
//

#ifndef PROCESSOR_CPU_H
#define PROCESSOR_CPU_H

#include "global.h"

void processor(const char *const binfile_path);

#endif //PROCESSOR_CPU_H
