//
// Created by User on 04.11.2021.
//

#ifndef PROCESSOR_ASSEMBLER_H
#define PROCESSOR_ASSEMBLER_H

const char assembler_logfile_path[] = "../assembler_log.txt";

void assembler(const char *const asmfile_path, const char *const binfile_path);

#endif //PROCESSOR_ASSEMBLER_H
