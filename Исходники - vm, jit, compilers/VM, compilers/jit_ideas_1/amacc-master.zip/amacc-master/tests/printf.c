#include <stdio.h>

int main()
{
    printf("arg1 %s %s %s %s %s\n", "arg2", "arg3", "arg4", "arg5", "arg6");

    return 0;
}
