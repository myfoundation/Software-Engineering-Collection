#include <stdio.h>

int main()
{
    int i;
    i = 10;
    printf("hello, world %d \n", i);
    return 0;
}
