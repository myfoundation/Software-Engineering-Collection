#include <stdio.h>

int main()
{
    // single-line comment

    /* C-style multiline comments
     */
    return 0;
}
