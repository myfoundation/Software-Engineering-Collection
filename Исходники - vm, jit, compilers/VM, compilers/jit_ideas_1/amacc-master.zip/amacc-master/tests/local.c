int main(void)
{
    int n = 10;
    printf("%d\n", n);
    char cc = 'a';
    char *ptr = &cc;
    printf("%c\n", *ptr);
    int *c = &n;
    printf("%d\n", *c);
    int r;
    r = 0;
    return r;
}
