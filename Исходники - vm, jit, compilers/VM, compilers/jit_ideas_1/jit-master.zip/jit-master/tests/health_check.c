#include "test.h"

int main(void)
{
	return TEST_SUCESS;
}
