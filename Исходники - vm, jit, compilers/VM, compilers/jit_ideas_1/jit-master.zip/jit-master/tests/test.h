#ifndef TEST_H
#define TEST_H

#define TEST_SUCESS (0)
#define TEST_FAILURE (1)

#endif /* !TEST_H */
