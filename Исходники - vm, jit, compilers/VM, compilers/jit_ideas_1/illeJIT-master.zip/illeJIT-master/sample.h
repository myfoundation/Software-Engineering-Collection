#pragma once

#include "stack.h"

void  sample(struct val_stack *s);
