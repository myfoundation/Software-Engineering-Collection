# thunder
A portable JIT framework

Thunder is a portable framework for making JIT translators, with backends (so far) for x86, amd64, arm32 and mips.
It is used for the runtime system of the Oxford Oberon-2 Compiler, but usable separately.
Details and a tutorial can be found at Spivey's Corner: https://spivey.oriel.ox.ac.uk/corner/Thunder.
