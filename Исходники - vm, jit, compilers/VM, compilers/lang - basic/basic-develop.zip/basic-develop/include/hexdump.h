#ifndef __HEXDUMP_H__
#define __HEXDUMP_H__

void hexdump ( char *desc, void *addr, int len );

#endif // __HEXDUMP_H__
