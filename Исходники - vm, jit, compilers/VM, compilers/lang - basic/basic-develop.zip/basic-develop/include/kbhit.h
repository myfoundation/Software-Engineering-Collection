#ifndef __KBHIT_H__
#define __KBHIT_H__

int kbhit(void);

#endif // __KBHIT_H__
