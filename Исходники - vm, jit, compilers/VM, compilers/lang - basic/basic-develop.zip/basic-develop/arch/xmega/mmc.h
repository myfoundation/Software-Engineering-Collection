#ifndef __MMC_H__
#define __MMC_H__

#include "diskio.h"

#endif // __MMC_H__
