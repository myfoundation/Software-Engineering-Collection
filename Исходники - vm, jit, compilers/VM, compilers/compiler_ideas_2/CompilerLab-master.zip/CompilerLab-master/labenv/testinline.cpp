__attribute__((__always_inline__)) inline int add(int a, int b)
{
	return a + b;
}
