cd parser
git pull origin master
cd ..
cd semantic
git pull origin master
cd ..
cd LLVM-Simple-Wrapper
git pull origin master
cd ..
