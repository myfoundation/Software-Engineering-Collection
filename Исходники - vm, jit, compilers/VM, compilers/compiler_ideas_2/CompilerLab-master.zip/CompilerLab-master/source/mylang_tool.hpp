#ifndef MYLANG_TOOL_HPP
#define MYLANG_TOOL_HPP

namespace mylang {

//

}

#endif
