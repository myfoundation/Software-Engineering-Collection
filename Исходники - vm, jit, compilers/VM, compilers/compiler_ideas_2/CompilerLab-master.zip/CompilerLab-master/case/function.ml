program test()
	function cece()
		return integer;
	is
	var result is integer;
	begin
		result := 1;
		return result;
	end
is
var buf is integer;
begin
	buf := cece();
end
