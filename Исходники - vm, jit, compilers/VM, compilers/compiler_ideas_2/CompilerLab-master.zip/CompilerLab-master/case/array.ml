program test()
	type testArray is array of 20 integer;
is
	var buf is testArray;
begin
	buf[0] := 100;
end
