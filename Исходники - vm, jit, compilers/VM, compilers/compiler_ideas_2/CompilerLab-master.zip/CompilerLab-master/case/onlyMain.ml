program test()
is
	var buf is integer;
begin
	buf := 0;
end
