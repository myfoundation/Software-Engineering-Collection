doxygen ./Doxyfile
firefox ./docs/html/index.html
