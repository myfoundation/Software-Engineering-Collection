/*
    utility.c
    Copyright (C) 2010  Patrick Head

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <string.h>

#include "utility.h"

char *itos(int n)
{
	static char s[12];
	int i, sign;

	memset(s, 0, 12);

	if ((sign = n) < 0)
	{
		n = -n;
		if (n < 0)
		{
			++n;
			n = -n;
		}
	}

	i = 0;
	do
	{
		s[i++] = n % 10 + '0';
	} while (((n /= 10) > 0) && (i < 10));

	if (sign < 0)
		s[i++] = '-';

	s[i] = '\0';

	reverse(s);

	return s;
}

void reverse(char *s)
{
	int i, j;
	char c;

	for (i = 0, j = strlen(s)-1; i<j; i++, j--)
	{
		c = s[i];
		s[i] = s[j];
		s[j] = c;
	}
}

