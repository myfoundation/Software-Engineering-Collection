const StackMachine = require('./stack-machine');
const instructions = require('./instructions');

module.exports = {
  StackMachine,
  instructions
};
