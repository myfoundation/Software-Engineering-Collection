export default class RRElement {

    constructor() {
        this.layoutInfo = null;
    }

    setLayoutInfo(layoutInfo) {
        this.layoutInfo = layoutInfo;
    }

    getLayoutInfo() {
        return this.layoutInfo;
    }

}
