#include "../common/Memory.hpp"

#include "Nfa.hpp"
