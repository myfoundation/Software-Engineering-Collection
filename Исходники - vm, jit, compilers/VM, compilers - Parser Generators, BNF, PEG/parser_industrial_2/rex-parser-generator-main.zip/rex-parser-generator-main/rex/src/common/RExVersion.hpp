/*
 * RExVersion.hpp
 *
 *  Created on: 22.11.2012
 *      Author: Gunther
 */

#ifndef REXVERSION_HPP
#define REXVERSION_HPP
#define REX_VMAJOR   "6"
#define REX_VMINOR   "1-SNAPSHOT"
#define REX_DAY      12
#define REX_MONTH    "December"
#define REX_YEAR     2024
#endif
