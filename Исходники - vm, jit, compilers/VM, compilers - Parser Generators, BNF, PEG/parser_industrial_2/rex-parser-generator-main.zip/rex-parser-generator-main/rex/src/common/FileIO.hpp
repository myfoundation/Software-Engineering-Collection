/*
 * getContent.hpp
 *
 *  Created on: 26.08.2009
 *      Author: Gunther
 */

#ifndef FILEIO_HPP
#define FILEIO_HPP

class FileIO
{
public:
  static char *getContent(const char *name);
};

#endif

