/*
 * Token.cpp
 *
 *  Created on: 18.08.2008
 *      Author: Gunther
 */

#include "../common/Memory.hpp"
#include "Token.hpp"
