/*
 * AutomaticSemicolonInsertion.cpp
 *
 *  Created on: 27-Nov-2014
 *      Author: Gunther
 */

#include "../common/Memory.hpp"
#include "AutomaticSemicolonInsertion.hpp"
