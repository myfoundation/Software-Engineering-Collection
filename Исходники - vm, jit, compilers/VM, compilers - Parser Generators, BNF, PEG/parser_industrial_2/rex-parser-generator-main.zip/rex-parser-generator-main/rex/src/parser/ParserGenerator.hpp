/*
 * LL.hpp
 *
 *  Created on: Aug 12, 2009
 *      Author: Gunther
 */

#ifndef PARSERGENERATOR_HPP
#define PARSERGENERATOR_HPP

int generateParser(int argc, char **argv);

#endif
