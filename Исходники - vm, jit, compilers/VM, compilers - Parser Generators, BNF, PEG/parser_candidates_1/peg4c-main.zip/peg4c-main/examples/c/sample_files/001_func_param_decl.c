int a(long (char));
int b(long (c));
int d(long e(char));
typedef char h;
int f(long g(h));