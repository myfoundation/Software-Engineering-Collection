#include "008_pp_macro.c"

D b;
