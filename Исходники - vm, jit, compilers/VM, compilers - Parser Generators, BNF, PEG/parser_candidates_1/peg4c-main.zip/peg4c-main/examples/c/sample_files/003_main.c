int main(int narg, char ** args) {
    return 0;
}