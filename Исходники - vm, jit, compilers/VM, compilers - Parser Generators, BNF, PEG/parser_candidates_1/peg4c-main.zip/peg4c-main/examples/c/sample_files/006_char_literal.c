
// simple-escape sequences
char a = '\'';
char b = '\"';
char b = '\a';
char b = '\?';
char b = '\b';
char b = '\f';
char b = '\b';
char b = '\n';
char b = '\r';
char b = '\t';
char b = '\v';
char b = '\\';