int test_tokenizer_single_char(void);
int test_tokenizer_alphanumeric(void);
int test_tokenizer_hexadecimal(void);
int test_tokenizer_test_parser_token(void);
void test_parser_cleanup(void);
int test_parser_doc(void);

