int test_sequence(void);
int test_repeat(void);
int test_list(void);
int test_lookahead(void);
void test_rule_cleanup(void);

