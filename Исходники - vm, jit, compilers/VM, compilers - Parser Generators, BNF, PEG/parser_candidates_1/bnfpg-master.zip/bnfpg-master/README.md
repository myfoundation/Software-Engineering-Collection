# bnfpg

A compile-time Backus-Naur Form Parser Generator for C++.
