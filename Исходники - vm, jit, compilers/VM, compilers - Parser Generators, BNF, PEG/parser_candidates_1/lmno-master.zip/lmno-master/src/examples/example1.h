#define PLUS                            1
#define MINUS                           2
#define DIVIDE                          3
#define TIMES                           4
#define INTEGER                         5
