/* $Id: bnf_sparser.h,v 1.1 2012/08/27 13:55:31 luis Exp $
 * Author: Luis Colorado <lc@luiscoloradosistemas.com>
 * Date: lun ago 27 08:27:13 CEST 2012
 * Disclaimer: (C) 2012 LUIS COLORADO SISTEMAS S.L.U.
 *                 All rights reserved.
 */

#ifndef BNF_SPARSER_H
#define BNF_SPARSER_H

void do_lex_nocolor(void);

#endif /* BNF_SPARSER_H */
/* $Id: bnf_sparser.h,v 1.1 2012/08/27 13:55:31 luis Exp $ */
