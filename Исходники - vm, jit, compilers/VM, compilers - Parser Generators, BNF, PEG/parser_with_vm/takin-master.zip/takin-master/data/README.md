# Takin 2 - Data Files

An inelastic neutron scattering software package.

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.4117437.svg)](https://doi.org/10.5281/zenodo.4117437)


## Project history

  - Forked project from https://github.com/t-weber/takin-data on 20 June 2019.
