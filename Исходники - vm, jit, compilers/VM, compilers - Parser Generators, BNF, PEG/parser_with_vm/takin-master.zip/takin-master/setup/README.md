# Takin 2 - Installation Module

Meta-package which contains the build and install scripts.

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.4117437.svg)](https://doi.org/10.5281/zenodo.4117437)
