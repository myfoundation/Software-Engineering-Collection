#!/bin/bash

./build_lin/build.sh  distri bullseye  setup_buildenv 0  build_py_modules 1
