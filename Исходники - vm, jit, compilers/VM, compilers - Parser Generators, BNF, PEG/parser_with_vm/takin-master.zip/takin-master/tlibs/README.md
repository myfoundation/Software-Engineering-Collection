# tlibs

A physical-mathematical C++ template library.

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.4117437.svg)](https://doi.org/10.5281/zenodo.4117437)


## Project history

  - Forked from https://github.com/t-weber/tlibs on 21 June 2019.
