# Takin 2 - Magnetic Core and Tools Module

This project comprises:
  - *Takin* modules concerning magnetic and polarised scattering. 
  - Other tools that are not directly included in *Takin's* core module.

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.4117437.svg)](https://doi.org/10.5281/zenodo.4117437)


## Project history

  - Forked project from https://github.com/t-weber/magtools on 8 November 2018.
  - Forked and merged project from https://code.ill.fr/tweber/in20tools on 20 June 2019.
