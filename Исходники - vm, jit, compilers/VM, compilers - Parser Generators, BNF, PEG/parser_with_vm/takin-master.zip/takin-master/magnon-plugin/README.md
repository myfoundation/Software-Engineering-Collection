# Magnons

Takin plug-in module calculating magnon dispersions.