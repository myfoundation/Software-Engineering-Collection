#pragma once

#include <glue/value.h>

namespace peg_parser {
  glue::MapValue glue();
}
