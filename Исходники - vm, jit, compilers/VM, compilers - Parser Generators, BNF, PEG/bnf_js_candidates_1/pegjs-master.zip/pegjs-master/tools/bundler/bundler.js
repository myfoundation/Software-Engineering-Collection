#!/usr/bin/env node

"use strict";

require( "webpack-nano/bin/wp" );
