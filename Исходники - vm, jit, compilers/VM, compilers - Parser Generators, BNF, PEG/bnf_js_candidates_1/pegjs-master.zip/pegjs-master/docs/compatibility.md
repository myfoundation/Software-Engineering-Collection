## Compatibility

Both the parser generator and generated parsers should run well in the following environments:

* Node.js 8+
* Internet Explorer 11
* Microsoft Edge
* Firefox
* Chrome
* Opera
