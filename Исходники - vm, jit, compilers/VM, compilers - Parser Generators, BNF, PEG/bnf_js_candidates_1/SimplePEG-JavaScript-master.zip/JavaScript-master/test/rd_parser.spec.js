var should = require('chai').should();
var rd_parser = require('./../src/rd_parser');

describe('rd_parser - ', function() {
    it('should exist', function () {
        should.exist(rd_parser);
    });
});
