#ifndef COMMON_H
#define COMMON_H

#include <stddef.h>
#include <stdbool.h>
#include <inttypes.h>

#define IDX_MAX 	(SIZE_MAX - 1)
#define IDX_ERR 	(SIZE_MAX)

#endif // COMMON_H
