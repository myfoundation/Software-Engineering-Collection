parse
=====

https://github.com/mikaelpatel/parse

Yet another top down parser generator