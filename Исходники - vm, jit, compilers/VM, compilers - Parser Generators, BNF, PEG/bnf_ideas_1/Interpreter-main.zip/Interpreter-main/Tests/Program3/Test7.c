// ***************************************************
// * CS460: Programming Assignment 3: Test Program 7 *
// ***************************************************
procedure main (void)
{
  char char; // syntax error: reserved word "char" cannot be for the name of a variable
}
