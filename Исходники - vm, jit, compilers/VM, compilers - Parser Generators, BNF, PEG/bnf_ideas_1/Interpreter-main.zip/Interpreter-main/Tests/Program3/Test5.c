// ***************************************************
// * CS460: Programming Assignment 3: Test Program 5 *
// ***************************************************
procedure main (void)
{
  char buffer[+10];

  buffer[0] = "_\"; // syntax error: closing quote is missing.
}
