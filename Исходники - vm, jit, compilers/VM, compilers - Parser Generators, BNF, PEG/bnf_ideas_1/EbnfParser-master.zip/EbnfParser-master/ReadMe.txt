EbnfParser --- an ISO EBNF notation parser
/////////////////////////////////////////////////////

This is an ISO EBNF notation parser by katahiromz.

/////////////////////////////////////////////////////
// Katayama Hirofumi MZ (katahiromz) [A.N.T.]
// Homepage     http://katahiromz.web.fc2.com
// BBS          http://katahiromz.bbs.fc2.com
// E-Mail       katayama.hirofumi.mz@gmail.com
/////////////////////////////////////////////////////
