#ifndef MAPPER_H
#define MAPPER_H

#include "tree.h"

void render_production(SDL_Renderer *renderer, tree root);
int render_window(tree ast);

#endif /* MAPPER_H */