# ebnfParser

A simple parser for [EBNF](https://en.wikipedia.org/wiki/Extended_Backus%E2%80%93Naur_form) like grammars.

> ebnfParser is written in ES6 class syntax and will only work in modern enviroments!



