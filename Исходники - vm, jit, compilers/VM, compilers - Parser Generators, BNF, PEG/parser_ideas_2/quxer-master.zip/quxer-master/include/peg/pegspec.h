#ifndef PEGSPEC_H
#define PEGSPEC_H

#include "utils/writer.h"

grammar_t* init_metagrammar();

#endif

