#!/bin/bash

#I need a gcc platform to test this

#IF [ -f ./tower ] ./tower DSA.Vent.Tower.dbnf DSA::Vent::Tower::CPPGenerator

#gcc -I..\..\..\ *.cpp -o tower
