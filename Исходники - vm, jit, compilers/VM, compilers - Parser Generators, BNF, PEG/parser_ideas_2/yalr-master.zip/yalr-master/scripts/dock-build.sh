#!/usr/bin/env sh
CC=gcc CXX=g++ ./scripts/build.sh release
