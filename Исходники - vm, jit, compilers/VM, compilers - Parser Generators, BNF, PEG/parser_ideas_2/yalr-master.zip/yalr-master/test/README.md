## Unit test numbering

- 00 - 19 = parser
- 20 - 39 = analyzer
- 40 - 59 = table generation
- 60 - 79 = code generation
- 80 - 99 = generated lexer
- A0 - B9 = generated parser
- C0 - D9 = command line handling

