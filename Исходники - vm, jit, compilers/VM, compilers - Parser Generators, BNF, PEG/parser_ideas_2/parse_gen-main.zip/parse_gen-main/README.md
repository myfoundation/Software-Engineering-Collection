https://github.com/digital-nitrate/parse_gen

doc/README.md