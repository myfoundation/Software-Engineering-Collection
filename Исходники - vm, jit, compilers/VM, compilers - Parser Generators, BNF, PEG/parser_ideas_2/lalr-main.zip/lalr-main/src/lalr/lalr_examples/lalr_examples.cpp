
int main()
{   
    extern void lalr_hello_world_example();
    lalr_hello_world_example();
           
    extern void lalr_calculator_example();
    lalr_calculator_example();

    extern void lalr_error_handling_calculator_example();
    lalr_error_handling_calculator_example();
 
    extern void lalr_xml_example();
    lalr_xml_example();
   
    extern void lalr_json_example();
    lalr_json_example();

    return 0;
}
