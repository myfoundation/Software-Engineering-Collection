//
// main.cpp
// Copyright (c) Charles Baker.  All rights reserved.
//

#include <UnitTest++/UnitTest++.h>
#include <UnitTest++/TestReporterStdout.h>

int main( int /*argc*/, char** /*argv*/ )
{
    return UnitTest::RunAllTests();
}
