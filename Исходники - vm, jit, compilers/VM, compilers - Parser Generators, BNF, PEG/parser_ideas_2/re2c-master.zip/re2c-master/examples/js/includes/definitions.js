const INT = 1
const FLOAT = 2
const NAN = 3

/*!re2c
    number = [1-9][0-9]*;
*/
