type number = Int | Float | NaN

%{
    number = [1-9][0-9]*;
%}
