#!/bin/sh

autoreconf -i -W all
