//
// Created by dtpreda on 04/08/22.
//

#ifndef PARSER_TESTUTILS_H
#define PARSER_TESTUTILS_H

#include <string>

class TestUtils {
public:
    static std::string openPrediCtiveFile(const std::string& path);
};


#endif //PARSER_TESTUTILS_H
