For any terminal X:

NULLABLE(X) = False

For non-terminals:

NULLABLLE(SStart) = false

NULLABLLE(Start) = false

NULLABLLE(Tokens) = false

NULLABLE(NextToken) = true

NULLABLLE(Token) = false

NULLABLLE(Skip) = true

NULLABLE(SkipExpression) = true

NULLABLLE(Rules) = false

NULLABLLE(NextRule) = false

NULLABLLE(Expansion) = true

NULLABLLE(Closure) = false

NULLABLLE(ExpansionBlock) = false

NULLABLLE(NextExpansionBlock) = false

NULLABLLE(Annotation) = true

NULLABLLE(AnnotationOption) = false