/*
 * Copyright 2014 Anton Karmanov
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

//Platform-independent functions used by file API.

#ifndef SYNSAMPLE_CORE_PLATFORM_FILE_COMMON_H_INCLUDED
#define SYNSAMPLE_CORE_PLATFORM_FILE_COMMON_H_INCLUDED

#include <cstddef>
#include <memory>
#include <vector>

#include "gc.h"
#include "stringex.h"

namespace syn_script {
	namespace platform {

		std::size_t pf_get_path_drive_letter_end(const StringLoc& path);
		std::unique_ptr<char[]> pf_get_current_directory();
		void pf_list_files(const std::string& path_str, std::vector<StringLoc>& list);

		std::size_t get_path_root_end(const StringLoc& path);
		std::string get_path_with_slash(const StringLoc& path);

	}
}

#endif//SYNSAMPLE_CORE_PLATFORM_FILE_COMMON_H_INCLUDED
