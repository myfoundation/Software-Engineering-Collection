#ifndef P_H
#define P_H

#define T000   0 /* $a */
#define T001   1 /* e */
#define T002   2 /* t */
#define T003   3 /* tz */
#define T004   4 /* f */
#define T005   5 /* fz */
#define T006   6 /* a */
#define T007   7 /* m */
#define T008   8 /* ( */
#define T009   9 /* ) */
#define T010  10 /* N */
#define T011  11 /* + */
#define T012  12 /* - */
#define T013  13 /* * */
#define T014  14 /* / */
#define T015  15 /* $e */

void pgparse(char *p);

#endif /* P_H */
