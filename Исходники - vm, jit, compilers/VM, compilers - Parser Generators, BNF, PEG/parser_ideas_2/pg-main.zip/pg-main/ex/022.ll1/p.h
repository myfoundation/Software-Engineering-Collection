#ifndef P_H
#define P_H

#define T000   0 /* $a */
#define T001   1 /* e */
#define T002   2 /* ez */
#define T003   3 /* o */
#define T004   4 /* V */
#define T005   5 /* N */
#define T006   6 /* ( */
#define T007   7 /* ) */
#define T008   8 /* $e */

void pgparse(char *p);

#endif /* P_H */
