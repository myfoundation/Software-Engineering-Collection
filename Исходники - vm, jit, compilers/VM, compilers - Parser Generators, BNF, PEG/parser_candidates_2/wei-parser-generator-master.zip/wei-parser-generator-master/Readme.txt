This is an LL(k) parser generator.

Project page: https://github.com/Halajohn/wei-parser-generator
Project discussion group: http://groups.google.com/group/wei-parser-generator
