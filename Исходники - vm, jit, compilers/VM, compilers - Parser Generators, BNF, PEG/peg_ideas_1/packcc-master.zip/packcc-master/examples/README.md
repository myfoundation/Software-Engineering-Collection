# Examples

## Overview

In this directory, examples are stored.

## Example List

- [Desktop Calculator](calc.peg)
- [Simple AST builder](ast-calc.peg)
- [AST Builder for Tiny-C](ast-tinyc)

For details, see PackCC [README.md](../README.md).
