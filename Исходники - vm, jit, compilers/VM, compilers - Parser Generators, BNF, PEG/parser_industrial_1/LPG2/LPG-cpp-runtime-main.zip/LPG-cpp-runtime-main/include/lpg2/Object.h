#pragma once
struct Object
{
	virtual  ~Object()= default;
};
