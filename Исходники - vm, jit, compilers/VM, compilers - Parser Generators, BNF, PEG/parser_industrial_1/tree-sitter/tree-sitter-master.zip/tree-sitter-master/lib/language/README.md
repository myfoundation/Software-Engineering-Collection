# Tree-sitter Language

This crate provides a `LanguageFn` type for grammars to create `Language` instances from a parser,
without having to worry about the `tree-sitter` crate version not matching.
