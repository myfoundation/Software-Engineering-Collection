# Tree-sitter Generate

This helper crate implements the logic for the `tree-sitter generate` command,
and can be used by external tools to generate a parser from a grammar file.
