import pkg from "./package.json" with { type: "json" };
// <- keyword
//               ^ string
//                               ^ keyword
