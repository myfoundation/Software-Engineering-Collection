# C++ target source

The contents of this folder are resulting in the file ``../c++.tlt``.

The C++ target enables UniCC to support the C++ programming language in its
program module generator. Using this target, UniCC is capable to generate
parsers expressed in C++ and using C++ semantics.

This target is a fork of the C target, and was extended to classes. Yet, input
processing is done the same way as in the C target, but this may be changed in
the future.
