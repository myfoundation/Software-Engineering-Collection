/* Typedef for production information table */
typedef struct
{
    const char*	definition;
    const char*	emit;
    int			length;
    int			lhs;
} @@prefix_prodinfo;
