/* Typedef for production information table */
typedef struct
{
    char*	definition;
    char*	emit;
    int		length;
    int		lhs;
} @@prefix_prodinfo;
