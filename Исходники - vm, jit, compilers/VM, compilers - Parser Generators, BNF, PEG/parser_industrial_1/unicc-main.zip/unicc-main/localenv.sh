#!/bin/sh
export PATH="`pwd`:$PATH"
export UNICC_TPLDIR="`pwd`/targets"
