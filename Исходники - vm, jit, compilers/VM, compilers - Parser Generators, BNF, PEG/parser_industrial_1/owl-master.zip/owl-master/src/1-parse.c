#define OWL_PARSER_IMPLEMENTATION
#include "1-parse.h"
