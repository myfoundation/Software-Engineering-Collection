# calc

*Calc* is a simple calculator program which supports basic arithmetic.

Calc requires Owl to be built (at `../../owl`) and the readline library to be installed on the system.  Build it with `make`:

```
$ make
```

The calculator can be run by typing `./calc`.
