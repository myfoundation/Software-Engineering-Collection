# lisp.egg

This is a simple, dynamically-scoped lisp written in Egg.  Run it using `../../egg lisp.egg`.  You can find some example programs in the `example/` directory.
