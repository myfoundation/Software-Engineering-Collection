#define OWL_PARSER_IMPLEMENTATION
#include "parser.h"
