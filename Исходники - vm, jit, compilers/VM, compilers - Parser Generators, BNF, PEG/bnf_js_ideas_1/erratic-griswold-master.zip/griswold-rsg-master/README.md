# Use `erratic` to generate eerie poems from a BNF grammar. 

The grammar was taken from a benchmark for the Icon programming language
benchmark called `rsg` written by the late Ralph E. Griswold.

## Usage
`node eerie-poem.js` 

