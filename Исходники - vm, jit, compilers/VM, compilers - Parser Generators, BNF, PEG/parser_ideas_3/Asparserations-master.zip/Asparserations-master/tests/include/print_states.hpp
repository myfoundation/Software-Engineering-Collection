namespace asparserations {
  namespace table {
    class Table;
  }
  void print_states(const asparserations::table::Table&);
}
