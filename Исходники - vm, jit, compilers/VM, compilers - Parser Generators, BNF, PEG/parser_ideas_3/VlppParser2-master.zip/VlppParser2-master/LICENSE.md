See https://github.com/vczh-libraries/License/blob/master/README.md for the detail.
