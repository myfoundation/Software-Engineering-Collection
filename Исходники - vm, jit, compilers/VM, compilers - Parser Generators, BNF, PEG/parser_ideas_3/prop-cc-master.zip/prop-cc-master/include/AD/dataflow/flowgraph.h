#ifndef flow_graph_interface_h
#define flow_graph_interface_h

#include <AD/generic/generic.h>
#include <AD/dataflow/node>

class FlowGraphBase
{
public:
  FlowGraphBase();
  virtual ~FlowGraphBase();
};

#endif
