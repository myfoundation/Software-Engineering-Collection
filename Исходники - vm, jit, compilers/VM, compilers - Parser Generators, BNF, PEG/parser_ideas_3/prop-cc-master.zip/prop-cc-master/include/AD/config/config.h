#ifndef prop_library_configuration_h
#define prop_library_configuration_h
#define PROP_BOOL_IS_DEFINED		1
#define PROP_EXPLICIT_IS_DEFINED	1
#define PROP_HAS_GETRUSAGE
#define PROP_HAS_TIMES
#endif
