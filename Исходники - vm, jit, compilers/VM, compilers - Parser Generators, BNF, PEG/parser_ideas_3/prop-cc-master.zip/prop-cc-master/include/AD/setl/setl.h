#ifndef setl_h
#define setl_h

#include <AD/generic/generic.h>
#include <AD/pretty/postream.h>

class SETL
{

public:
};

#endif
