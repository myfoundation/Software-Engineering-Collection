extern void prop_trace(const char *, const char *, int);
