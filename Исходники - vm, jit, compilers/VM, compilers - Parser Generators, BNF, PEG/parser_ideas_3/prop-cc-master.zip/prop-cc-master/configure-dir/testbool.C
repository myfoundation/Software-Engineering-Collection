bool dummy;
