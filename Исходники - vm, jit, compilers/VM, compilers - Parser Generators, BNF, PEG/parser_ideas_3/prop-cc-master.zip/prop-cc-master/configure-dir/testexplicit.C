class dummy {
public:
   explicit dummy(int);
};
