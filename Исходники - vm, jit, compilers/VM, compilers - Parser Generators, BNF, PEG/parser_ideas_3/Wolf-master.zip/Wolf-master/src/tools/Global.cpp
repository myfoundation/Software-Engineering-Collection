// Global settings

// Variable
const char* InputFileName = nullptr;

const char* StartRule = nullptr;

// Flags
bool FlagWithoutBranches = false;

bool FlagSkipUselessRule = true;