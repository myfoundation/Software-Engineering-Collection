#include "Lexer.hpp"
/*
bool Lexer::OpenFile(const char* file_name) {
    return buffer_.OpenFile(file_name);
}

Token Lexer::GetToken() {

}

void Lexer::Rollback(size_t state) {

}
*/