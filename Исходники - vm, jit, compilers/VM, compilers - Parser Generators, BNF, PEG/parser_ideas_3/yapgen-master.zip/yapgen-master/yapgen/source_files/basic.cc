
@begin
include "basic.h"
@end

// - time measuring data structures -
#if SYSTEM_TYPE == SYSTEM_TYPE_UNIX
struct timeval tv;
struct timeval stv;
#endif

/*
 * methods of generated structures
 */

