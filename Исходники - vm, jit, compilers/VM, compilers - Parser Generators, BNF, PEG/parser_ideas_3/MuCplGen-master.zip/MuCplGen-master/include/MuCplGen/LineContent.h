#pragma once
#include <string>

namespace MuCplGen
{
	struct LineContent
	{
		std::string content;
		size_t line_no;
	};
}
