//
//  syntax.cpp
//  pomelo
//
//  Created by Edmund Kapusniak on 11/12/2017.
//  Copyright © 2017 Edmund Kapusniak.
//
//  Licensed under the MIT License. See LICENSE file in the project root for
//  full license information. 
//

#include "syntax.h"




directive::directive()
    :   specified( false )
{
}



syntax::syntax( source_ptr source )
    :   source( source )
    ,   start( nullptr )
{
}

syntax::~syntax()
{
}


void syntax::print()
{
    
    printf( "%%include_header {%s}\n", include_header.text.c_str() );
    printf( "%%include_source {%s}\n", include_source.text.c_str() );
    printf( "%%user_value {%s}\n", user_value.text.c_str() );
    printf( "%%class_name {%s}\n", class_name.text.c_str() );
    printf( "%%token_type {%s}\n", token_type.text.c_str() );
    printf( "%%token_prefix {%s}\n", token_prefix.text.c_str() );
    printf( "%%nterm_prefix {%s}\n", nterm_prefix.text.c_str() );
    printf( "%%error_report {%s}\n", error_report.text.c_str() );
    
    for ( const auto& entry : terminals )
    {
        terminal* tsym = entry.second.get();

        printf
        (
            "%s : %d/%d/%d\n",
            source->text( tsym->name ),
            tsym->value,
            tsym->precedence,
            tsym->associativity
        );
    }
    
    for ( const auto& entry : nonterminals )
    {
        nonterminal* nsym = entry.second.get();

        printf
        (
            "%s : %d {%s}\n",
            source->text( nsym->name ),
            nsym->value,
            nsym->type.c_str()
        );

        if ( nsym->gspecified )
        {
            printf( "    @{%s}\n", nsym->gmerge.c_str() );
        }
        
        printf( "[\n" );
        for ( rule* rule : nsym->rules )
        {
            printf( "    " );
            for ( size_t i = 0; i < rule->locount; ++i )
            {
                const location& l = locations[ rule->lostart + i ];
                if ( l.conflicts )
                {
                    printf( "! " );
                }
                if ( l.sym )
                {
                    printf( "%s", source->text( l.sym->name ) );
                    if ( l.sparam )
                    {
                        printf( "(%s)", source->text( l.sparam ) );
                    }
                }
                else
                {
                    if ( rule->conflicts )
                    {
                        printf( "! " );
                    }
                    printf( "." );
                }
                printf( " " );
            }
            if ( rule->precedence )
            {
                terminal* prec = rule->precedence;
                printf
                (
                    "[%s : %d] ",
                    source->text( prec->name ),
                    prec->precedence
                );
            }
            printf( "{%s}\n", rule->action.c_str() );
        }
        
        printf( "]\n" );
    }

}


symbol::symbol( token name, bool is_terminal )
    :   name( name )
    ,   value( -1 )
    ,   is_special( false )
    ,   is_terminal( is_terminal )
{
}


terminal::terminal( token name )
    :   symbol( name, true )
    ,   precedence( -1 )
    ,   associativity( ASSOC_NONE )
{
}


nonterminal::nonterminal( token name )
    :   symbol( name, false )
    ,   gspecified( false )
    ,   defined( false )
    ,   erasable( false )
{
}


rule::rule( nonterminal* nterm )
    :   nterm( nterm )
    ,   lostart( 0 )
    ,   locount( 0 )
    ,   precedence( nullptr )
    ,   precetoken( NULL_TOKEN )
    ,   index( -1 )
    ,   actline( -1 )
    ,   actspecified( false )
    ,   conflicts( false )
    ,   reachable( false )
{
}
