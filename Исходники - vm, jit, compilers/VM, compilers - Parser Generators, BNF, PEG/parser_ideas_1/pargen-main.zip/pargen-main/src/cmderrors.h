#ifndef _CMDERRORS_H_
#define _CMDERRORS_H_

void error(const char* fmt, ...);
void warning(const char* fmt, ...);

#endif /* _CMDERRORS_H_ */
