#ifndef _DUMP_H
#define _DUMP_H

#include "parser.h"

void dump_state(Pstate* state);

#endif
