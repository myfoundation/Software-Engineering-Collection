#ifndef _PREPROC_H
#define _PREPROC_H

void pre_process(Pstate* state);

#endif /* _PREPROC_H */
