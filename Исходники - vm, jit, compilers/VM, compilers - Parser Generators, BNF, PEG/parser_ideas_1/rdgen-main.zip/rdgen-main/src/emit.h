#ifndef _EMIT_H
#define _EMIT_H

#include "parser.h"

#endif
