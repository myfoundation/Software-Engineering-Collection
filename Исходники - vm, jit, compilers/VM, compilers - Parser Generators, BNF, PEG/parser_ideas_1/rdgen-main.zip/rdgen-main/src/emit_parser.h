#ifndef _EMIT_PARSER_H
#define _EMIT_PARSER_H

#include "parser.h"

void emit_parser(Pstate* state);

#endif /* _EMIT_PARSER_H */
