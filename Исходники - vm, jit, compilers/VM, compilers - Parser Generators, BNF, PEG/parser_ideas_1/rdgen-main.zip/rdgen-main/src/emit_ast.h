#ifndef _EMIT_AST_H
#define _EMIT_AST_H

#include "parser.h"

void emit_ast(Pstate* state);

#endif /* _EMIT_AST_H */
