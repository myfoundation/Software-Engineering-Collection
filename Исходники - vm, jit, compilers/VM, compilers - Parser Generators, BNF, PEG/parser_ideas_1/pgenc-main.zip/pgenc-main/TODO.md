More testing for lang.h

Valgrind test for executables

Add string literals to the parsing language.
