# Parser generator

https://github.com/Creepsy/parser_generator

A parser generator for generating LR(1) parsers in C++. This parser generator is meant to be used together with [this](https://github.com/Creepsy/lexer_generator) lexer generator.