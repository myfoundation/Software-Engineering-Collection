# lexer_generator
A lexer generator written in C++ which creates a lexer in C++ depending on the given regex rules.
