// token.hpp
// Copyright (c) 2017-2023 Ben Hanson (http://www.benhanson.net/)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file licence_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
#ifndef PARSERTL_TOKEN_HPP
#define PARSERTL_TOKEN_HPP

#include <string>
#include <vector>

namespace parsertl
{
    template<typename iterator>
    struct token
    {
        using char_type = typename iterator::value_type::char_type;
        using iter_type = typename iterator::value_type::iter_type;
        using string = std::basic_string<char_type>;
        using string_view = std::basic_string_view<char_type>;
        using token_vector = std::vector<token<iterator>>;
        std::size_t id = static_cast<std::size_t>(~0);
        iter_type first = iter_type();
        iter_type second = iter_type();

        token() = default;

        token(const std::size_t id_, const iter_type& first_,
            const iter_type& second_) :
            id(id_),
            first(first_),
            second(second_)
        {
        }

        string str() const
        {
            return string(first, second);
        }

        string substr(const std::size_t soffset_,
            const std::size_t eoffset_) const
        {
            return string(first + soffset_, second - eoffset_);
        }

        string_view view() const
        {
            return string_view(first, length());
        }

        string_view subview(const std::size_t soffset_,
            const std::size_t eoffset_) const
        {
            return string_view(first + soffset_,
                length() - soffset_ - eoffset_);
        }

        std::size_t length() const
        {
            return second - first;
        }
    };
}

#endif
