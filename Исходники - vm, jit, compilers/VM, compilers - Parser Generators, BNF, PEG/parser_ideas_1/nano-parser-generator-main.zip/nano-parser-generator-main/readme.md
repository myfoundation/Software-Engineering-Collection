https://github.com/bogfrog7/nano-parser-generator
