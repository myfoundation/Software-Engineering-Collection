#pragma once

/* Используем глобальную переменную как простейший способ подсчёта ошибок. */
extern int g_errorsCount;
