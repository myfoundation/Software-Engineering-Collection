#include "stdafx.h"

#define BOOST_TEST_NO_MAIN 
#include <boost/test/included/unit_test.hpp>
