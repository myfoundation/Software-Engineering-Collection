#define TK_PLUS                            1
#define TK_MINUS                           2
#define TK_STAR                            3
#define TK_SLASH                           4
#define TK_PERCENT                         5
#define TK_LPAREN                          6
#define TK_RPAREN                          7
#define TK_NUMBER                          8
