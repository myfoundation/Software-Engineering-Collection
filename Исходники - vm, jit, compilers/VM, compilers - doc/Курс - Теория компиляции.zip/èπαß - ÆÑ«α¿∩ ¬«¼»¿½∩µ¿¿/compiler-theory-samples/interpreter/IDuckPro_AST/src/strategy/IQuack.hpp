#ifndef IQUACK_HPP_3f11b43c_6aa9_47db_802c_b745f1b3550f
#define IQUACK_HPP_3f11b43c_6aa9_47db_802c_b745f1b3550f

class IQuack
{
public:
    /**
      implements loud quack
      */
    virtual void quack() const = 0;

    virtual ~IQuack() { }
};

#endif // IQUACK_HPP_3f11b43c_6aa9_47db_802c_b745f1b3550f
