#include "AST_Stmt.h"
#include "AST_IVisitor.h"

namespace AST {

Stmt::Stmt()
{
}

Stmt::~Stmt()
{
}

} // AST
