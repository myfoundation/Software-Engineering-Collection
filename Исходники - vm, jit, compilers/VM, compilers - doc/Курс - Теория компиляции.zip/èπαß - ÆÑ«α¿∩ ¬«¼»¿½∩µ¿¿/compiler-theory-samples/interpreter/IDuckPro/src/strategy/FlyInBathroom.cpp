#include "FlyInBathroom.hpp"
#include <stdio.h>

FlyInBathroom::FlyInBathroom()
{
}

FlyInBathroom::~FlyInBathroom()
{
}

void FlyInBathroom::fly(Course, int &, int &) const
{
    puts("(swimming in deep bathroom waters)");
}
