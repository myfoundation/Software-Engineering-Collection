#include "simple/Basic/Name.h"

namespace simple {

Name *Name::New = nullptr;
Name *Name::Delete = nullptr;

} // namespace simple